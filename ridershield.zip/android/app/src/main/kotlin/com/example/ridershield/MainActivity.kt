package com.example.ridershield

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
