import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'home_dashboard.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  bool isSignUp = true;
  bool obscurePassword = true;
  bool isLoading = false;

  final nameController = TextEditingController();
  final phoneController = TextEditingController();
  final List<TextEditingController> emergencyControllers = [
  TextEditingController(),
];
  final passwordController = TextEditingController();

  static const gold = Color(0xFFFFC52E);
  static const background = Color(0xFF05090E);
  static const card = Color(0xFF0D151E);
  static const muted = Color(0xFF9BA8B7);

  @override
  void dispose() {
    nameController.dispose();
    phoneController.dispose();
    for (final controller in emergencyControllers) {
  controller.dispose();
}
    passwordController.dispose();
    super.dispose();
  }

  void showMessage(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(text),
        backgroundColor: card,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  Future<void> submitForm() async {
  FocusScope.of(context).unfocus();

  final name = nameController.text.trim();

  final phone = phoneController.text.replaceAll(
    RegExp(r'[^0-9]'),
    '',
  );

  // Collect all entered emergency contacts.
  final emergencies = emergencyControllers
      .map(
        (controller) => controller.text.replaceAll(
          RegExp(r'[^0-9]'),
          '',
        ),
      )
      .where((number) => number.isNotEmpty)
      .toList();

  final password = passwordController.text;

  if (isSignUp && name.isEmpty) {
    showMessage('Please enter your full name.');
    return;
  }

  if (phone.length < 10) {
    showMessage('Please enter a valid phone number.');
    return;
  }

  if (password.length < 6) {
    showMessage('Password must be at least 6 characters.');
    return;
  }

  // Require at least one emergency contact during signup.
  if (isSignUp && emergencies.isEmpty) {
    showMessage('Please add at least one emergency contact.');
    return;
  }

  if (isSignUp &&
      emergencies.any((number) => number.length < 10)) {
    showMessage(
      'Please enter a valid number for every emergency contact.',
    );
    return;
  }

  setState(() => isLoading = true);

  try {
    // Demo only: this is NOT real phone-number verification.
    final email = '$phone@ridershield.app';

    if (isSignUp) {
      final result = await FirebaseAuth.instance
          .createUserWithEmailAndPassword(
        email: email,
        password: password,
      );

      final user = result.user;

      if (user == null) {
        throw Exception('Account was created but user data is unavailable.');
      }

      await user.updateDisplayName(name);

      // Save the complete profile under the authenticated user's UID.
      await FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .set({
        'name': name,
        'phone': phone,
        'emergencyContacts': emergencies,
        'createdAt': FieldValue.serverTimestamp(),
      });

      // Confirm the write before navigating to the dashboard.
      final savedProfile = await FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .get();

      if (!savedProfile.exists ||
          savedProfile.data()?['emergencyContacts'] == null) {
        throw Exception(
          'Profile saved could not be verified. Please try again.',
        );
      }
    } else {
      await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
    }

    if (!mounted) return;

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => const HomeDashboard(),
      ),
    );
  } on FirebaseAuthException catch (e) {
    final message = switch (e.code) {
      'email-already-in-use' =>
        'Account already exists. Please log in.',
      'user-not-found' =>
        'Account not found. Please sign up first.',
      'wrong-password' || 'invalid-credential' =>
        'Phone number or password is incorrect.',
      'weak-password' =>
        'Password must have at least 6 characters.',
      'operation-not-allowed' =>
        'Enable Email/Password in Firebase Authentication.',
      'network-request-failed' =>
        'Check your internet connection.',
      _ => e.message ?? 'Authentication failed.',
    };

    if (mounted) showMessage(message);
  } on FirebaseException catch (e) {
    if (mounted) {
      showMessage(
        'Profile save failed (${e.code}). '
        'Check Firestore rules and internet connection.',
      );
    }
  } catch (e) {
    if (mounted) {
      showMessage('Something went wrong: $e');
    }
  } finally {
    if (mounted) {
      setState(() => isLoading = false);
    }
  }
}

  Widget buildInput({
    required String label,
    required String hint,
    required TextEditingController controller,
    required IconData icon,
    TextInputType keyboardType = TextInputType.text,
    bool password = false,
 }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            color: muted,
            fontSize: 13,
          ),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: controller,
          keyboardType: keyboardType,
          obscureText: password && obscurePassword,
          style: const TextStyle(color: Colors.white),
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: const TextStyle(color: Color(0xFF647180)),
            prefixIcon: Icon(icon, color: gold, size: 20),
            suffixIcon: password
                ? IconButton(
                    onPressed: () {
                      setState(() {
                        obscurePassword = !obscurePassword;
                      });
                    },
                    icon: Icon(
                      obscurePassword
                          ? Icons.visibility_off
                          : Icons.visibility,
                      color: muted,
                    ),
                  )
                : null,
            filled: true,
            fillColor: card,
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 14,
              vertical: 16,
            ),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(
                color: Color(0xFF263340),
              ),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(
                color: Color(0xFF263340),
              ),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(color: gold),
            ),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: background,
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            return SingleChildScrollView(
              padding: const EdgeInsets.symmetric(
                horizontal: 24,
                vertical: 28,
              ),
              child: Center(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 420),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      const SizedBox(height: 12),
                      const Icon(
                        Icons.shield_rounded,
                        size: 72,
                        color: gold,
                      ),
                      const SizedBox(height: 12),
                      const Text(
                        'RIDER SHIELD',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: gold,
                          fontSize: 27,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.5,
                        ),
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        'Your safety, our priority',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: muted, fontSize: 14),
                      ),
                      const SizedBox(height: 32),

                      Row(
                        children: [
                          Expanded(
                            child: _tab(
                              label: 'Sign Up',
                              selected: isSignUp,
                              onTap: () {
                                setState(() => isSignUp = true);
                              },
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: _tab(
                              label: 'Login',
                              selected: !isSignUp,
                              onTap: () {
                                setState(() => isSignUp = false);
                              },
                            ),
                          ),
                        ],
                      ),

                      const SizedBox(height: 26),

                      if (isSignUp) ...[
                        buildInput(
                          label: 'Full Name',
                          hint: 'Enter your full name',
                          controller: nameController,
                          icon: Icons.person_outline,
                        ),
                        const SizedBox(height: 18),
                      ],

                      buildInput(
                        label: 'Phone Number',
                        hint: '+91 Enter phone number',
                        controller: phoneController,
                        icon: Icons.phone_android,
                        keyboardType: TextInputType.phone,
                      ),

                      const SizedBox(height: 18),

                      buildInput(
                        label: 'Password',
                        hint: 'At least 6 characters',
                        controller: passwordController,
                        icon: Icons.lock_outline,
                        password: true,
                      ),

                      if (isSignUp) ...[
  const SizedBox(height: 18),
  const Align(
    alignment: Alignment.centerLeft,
    child: Text(
      'Emergency Contacts',
      style: TextStyle(
        color: Colors.white,
        fontWeight: FontWeight.w600,
      ),
    ),
  ),
  const SizedBox(height: 10),

  ...List.generate(emergencyControllers.length, (index) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        children: [
          Expanded(
            child: buildInput(
              label: 'Emergency Contact ${index + 1}',
              hint: 'Emergency phone number',
              controller: emergencyControllers[index],
              icon: Icons.contact_phone_outlined,
              keyboardType: TextInputType.phone,
            ),
          ),
          if (emergencyControllers.length > 1)
            IconButton(
              onPressed: () {
                setState(() {
                  final controller =
                      emergencyControllers.removeAt(index);
                  controller.dispose();
                });
              },
              icon: const Icon(
                Icons.remove_circle_outline,
                color: Colors.redAccent,
              ),
            ),
        ],
      ),
    );
  }),

  Align(
    alignment: Alignment.centerLeft,
    child: TextButton.icon(
      onPressed: () {
        setState(() {
          emergencyControllers.add(TextEditingController());
        });
      },
      icon: const Icon(Icons.add),
      label: const Text('Add another contact'),
    ),
  ),
],

                      const SizedBox(height: 26),

                     SizedBox(
                        height: 54,
                        child: ElevatedButton(
                          onPressed: isLoading ? null : submitForm,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: gold,
                            foregroundColor: Colors.black,
                          ),
                          child: isLoading
                              ? const CircularProgressIndicator()
                              : Text(
                                  isSignUp
                                      ? 'Create Account'
                                      : 'Login',
                                ),
                        ),
                      ),

                      const SizedBox(height: 28),

                      const Row(
                        children: [
                          Expanded(child: Divider(color: Color(0xFF263340))),
                          Padding(
                            padding: EdgeInsets.symmetric(horizontal: 12),
                            child: Text(
                              'RiderShield Emergency Safety',
                              style: TextStyle(
                                color: muted,
                                fontSize: 11,
                              ),
                            ),
                          ),
                          Expanded(child: Divider(color: Color(0xFF263340))),
                        ],
                      ),

                      const SizedBox(height: 24),
                      const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.verified_user_outlined,
                            color: muted,
                            size: 17,
                          ),
                          SizedBox(width: 8),
                          Flexible(
                            child: Text(
                              'Your safety matters',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: muted,
                                fontSize: 12,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _tab({
    required String label,
    required bool selected,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: isLoading ? null : onTap,
      borderRadius: BorderRadius.circular(10),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: selected ? gold.withValues(alpha: 0.12) : card,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: selected ? gold : const Color(0xFF263340),
            width: selected ? 1.5 : 1,
          ),
        ),
        child: Text(
          label,
          textAlign: TextAlign.center,
          style: TextStyle(
            color: selected ? gold : muted,
            fontWeight: FontWeight.w700,
          ),
        ),
      ),
    );
  }
}