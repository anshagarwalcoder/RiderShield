
import 'package:flutter/material.dart';

import 'package:geolocator/geolocator.dart';
import '../rider_location_service.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

class AlertSentScreen extends StatefulWidget {
  const AlertSentScreen({super.key});

  @override
  State<AlertSentScreen> createState() => _AlertSentScreenState();
}

class _AlertSentScreenState extends State<AlertSentScreen> {
  Position? _position;
  String? _locationError;

  @override
  void initState() {
    super.initState();
    _loadLocation();
  }

  Future<void> _loadLocation() async {
    try {
      final position = await RiderLocationService.getCurrentPosition();
      if (!mounted) return;

      setState(() {
        _position = position;
        _locationError = null;
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        _locationError = 'Location unavailable. Please check GPS permission.';
      });
    }
  }

  static const Color bg = Color(0xFF05080F);
  static const Color card = Color(0xFF101722);
  static const Color gold = Color(0xFFFFC342);
  static const Color green = Color(0xFF00E58B);
  static const Color border = Color(0xFF26303D);
  

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bg,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const SizedBox(height: 35),

              // Success icon
              Center(
                child: Container(
                  height: 112,
                  width: 112,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: green,
                      width: 3,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: green.withValues(alpha: 0.12),
                        blurRadius: 30,
                        spreadRadius: 8,
                      ),
                    ],
                  ),
                  child: const Icon(
                    Icons.check_rounded,
                    color: green,
                    size: 75,
                  ),
                ),
              ),

              const SizedBox(height: 25),

              const Text(
                'ALERT SENT',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: green,
                  fontSize: 25,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1,
                ),
              ),

              const SizedBox(height: 5),

              const Text(
                'Successfully',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: green,
                  fontSize: 17,
                ),
              ),

              const SizedBox(height: 15),

              const Text(
                'Your emergency alert has been sent to your contacts.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.white70,
                  fontSize: 13,
                  height: 1.5,
                ),
              ),

              const SizedBox(height: 28),

              
              // Location card
              Container(
                padding: const EdgeInsets.all(15),
                decoration: BoxDecoration(
                  color: card,
                  borderRadius: BorderRadius.circular(15),
                  border: Border.all(color: border),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Row(
                      children: [
                        Icon(
                          Icons.location_on_outlined,
                          color: green,
                          size: 25,
                        ),
                        SizedBox(width: 12),
                        Text(
                          'Current GPS Location',
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),

                    Text(
                      _position == null
                          ? (_locationError ?? 'Getting GPS location...')
                          : '${_position!.latitude.toStringAsFixed(6)}, '
                              '${_position!.longitude.toStringAsFixed(6)}',
                      style: const TextStyle(
                        color: Colors.white70,
                        fontSize: 12,
                      ),
                    ),
                    const SizedBox(height: 12),

                    SizedBox(
                      height: 220,
                      width: double.infinity,
                      child: _position == null
                          ? const Center(
                              child: CircularProgressIndicator(),
                            )
                          : ClipRRect(
                              borderRadius: BorderRadius.circular(12),
                              child: FlutterMap(
                                options: MapOptions(
                                  initialCenter: LatLng(
                                    _position!.latitude,
                                    _position!.longitude,
                                  ),
                                  initialZoom: 15,
                                ),
                                children: [
                                  TileLayer(
                                    urlTemplate:
                                        'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                                    userAgentPackageName:
                                        'com.ridershield.app',
                                  ),
                                  MarkerLayer(
                                    markers: [
                                      Marker(
                                        point: LatLng(
                                          _position!.latitude,
                                          _position!.longitude,
                                        ),
                                        width: 45,
                                        height: 45,
                                        child: const Icon(
                                          Icons.location_pin,
                                          color: Colors.red,
                                          size: 40,
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 15),
              
              
              // Alerted contacts card
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: card,
                  borderRadius: BorderRadius.circular(15),
                  border: Border.all(color: border),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Icon(
                          Icons.notifications_active_outlined,
                          color: green,
                          size: 20,
                        ),
                        const SizedBox(width: 9),
                        const Expanded(
                          child: Text(
                            'Alerted',
                            style: TextStyle(
                              fontWeight: FontWeight.w600,
                              fontSize: 14,
                            ),
                          ),
                        ),
                        IconButton(
                          icon: const Icon(
                            Icons.notifications_none_rounded,
                            color: Colors.white,
                          ),
                          onPressed: () {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text(
                                  'Alert preferences are not available yet.',
                                ),
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                    const SizedBox(height: 15),
                    const Text(
                      '- Mom (Primary)',
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 13,
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      '- Company Safety Team',
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 13,
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      '- Emergency Support',
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 13,
                      ),
                    ),
                  ],
                ),
              ),


              const SizedBox(height: 25),

              // Go to Home button
              SizedBox(
                height: 52,
                child: ElevatedButton(
                 onPressed: () {
  Navigator.of(context).popUntil(
    (route) => route.isFirst,
  );
},
                  style: ElevatedButton.styleFrom(
                    backgroundColor: gold,
                    foregroundColor: Colors.black,
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: const Text(
                    'Go to Home',
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }
}
