import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart';
import 'notifications_screen.dart';
import 'dart:io';
import 'package:image_picker/image_picker.dart';
import 'camera_screen.dart';

class LiveRideScreen extends StatefulWidget {
  const LiveRideScreen({super.key});

  @override
  State<LiveRideScreen> createState() => _LiveRideScreenState();
}

class _LiveRideScreenState extends State<LiveRideScreen> {
  static const Color bg = Color(0xFF050B12);
  static const Color card = Color(0xFF0D1722);
  static const Color yellow = Color(0xFFFFC52E);
  
  static const Color red = Color(0xFFFF302F);
  static const Color muted = Color(0xFFB7C0CE);

  final MapController _mapController = MapController();
  final ImagePicker _imagePicker = ImagePicker();

File? _capturedPhoto;
bool _isOpeningCamera = false;

Future<void> _openCamera() async {
  if (_isOpeningCamera) return;

  setState(() {
    _isOpeningCamera = true;
  });

  try {
    final XFile? photo = await _imagePicker.pickImage(
      source: ImageSource.camera,
      imageQuality: 85,
    );

    if (!mounted) return;

    if (photo != null) {
      setState(() {
        _capturedPhoto = File(photo.path);
      });

      _showPhotoPreview();
    }
  } catch (e) {
    if (!mounted) return;

    _message('Camera could not be opened: $e');
  } finally {
    if (mounted) {
      setState(() {
        _isOpeningCamera = false;
      });
    }
  }
}

void _showPhotoPreview() {
  if (_capturedPhoto == null) return;

  showDialog<void>(
    context: context,
    builder: (dialogContext) {
      return AlertDialog(
        backgroundColor: card,
        title: const Text(
          'Incident Photo',
          style: TextStyle(color: Colors.white),
        ),
        content: Image.file(
          _capturedPhoto!,
          fit: BoxFit.contain,
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(dialogContext);
            },
            child: const Text('Close'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(dialogContext);
              _openCamera();
            },
            child: const Text('Retake'),
          ),
        ],
      );
    },
  );
}
  StreamSubscription<Position>? _positionSubscription;
  Timer? _clockTimer;

  Position? _position;
  final List<LatLng> _routePoints = [];
  DateTime? _rideStartedAt;
  Duration _elapsed = Duration.zero;
  double _distanceMeters = 0;
  double _speedKmh = 0;
  String? _locationError;
  bool _isPaused = false;
  bool _isLocked = false;
  bool _isLoadingLocation = true;
  bool _rideStarted = false;

  @override
  void initState() {
    super.initState();
    _startRide();
    _clockTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted || !_rideStarted || _isPaused || _rideStartedAt == null) {
        return;
      }
      setState(() {
        _elapsed = DateTime.now().difference(_rideStartedAt!);
      });
    });
  }

  Future<void> _startRide() async {
    setState(() {
      _isLoadingLocation = true;
      _locationError = null;
      _rideStarted = true;
      _isPaused = false;
      _rideStartedAt ??= DateTime.now();
    });

    try {
      final serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        throw Exception('Location is off. Please enable GPS/location services.');
      }

      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }

      if (permission == LocationPermission.denied) {
        throw Exception('Location permission denied. Allow location to track your ride.');
      }
      if (permission == LocationPermission.deniedForever) {
        throw Exception('Location permission is blocked. Enable it in app settings.');
      }

      await _positionSubscription?.cancel();
      const settings = LocationSettings(
        accuracy: LocationAccuracy.bestForNavigation,
        distanceFilter: 3,
        timeLimit: Duration(seconds: 20),
      );

      // Try to show a current fix quickly, then continue with live updates.
      try {
        final initial = await Geolocator.getCurrentPosition(
          locationSettings: settings,
        );
        _acceptPosition(initial);
      } catch (_) {
        // The stream below may still obtain a fix.
      }

      _positionSubscription = Geolocator.getPositionStream(
        locationSettings: settings,
      ).listen(
        _acceptPosition,
        onError: (Object error) {
          if (!mounted) return;
          setState(() {
            _locationError = 'Live GPS update failed: $error';
            _isLoadingLocation = false;
          });
        },
      );

      if (mounted && _position == null) {
        setState(() => _isLoadingLocation = false);
      }
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _locationError = error.toString().replaceFirst('Exception: ', '');
        _isLoadingLocation = false;
      });
    }
  }

  void _acceptPosition(Position position) {
    if (!mounted) return;

    final point = LatLng(position.latitude, position.longitude);
    final previous = _position;

    // Do not accumulate inaccurate GPS points into the trip distance.
    final accurate = position.accuracy <= 50;
    if (accurate && !_isPaused) {
      if (previous != null && previous.accuracy <= 50) {
        final delta = Geolocator.distanceBetween(
          previous.latitude,
          previous.longitude,
          position.latitude,
          position.longitude,
        );

        // Ignore tiny GPS jitter and implausibly large jumps.
        if (delta >= 3 && delta <= 250) {
          _distanceMeters += delta;
          _routePoints.add(point);
        } else if (_routePoints.isEmpty) {
          _routePoints.add(point);
        }
      } else if (_routePoints.isEmpty) {
        _routePoints.add(point);
      }
    }

    setState(() {
      _position = position;
      _speedKmh = position.speed.isFinite && position.speed > 0
          ? position.speed * 3.6
          : 0;
      _isLoadingLocation = false;
      _locationError = null;
    });

    try {
      _mapController.move(point, 16);
    } catch (_) {
      // MapController may not be attached until the map has rendered.
    }
  }

  void _togglePause() {
    setState(() {
      _isPaused = !_isPaused;
      if (!_isPaused) {
        // Reset the clock anchor so paused time is not counted.
        _rideStartedAt = DateTime.now().subtract(_elapsed);
      }
    });
    _message(_isPaused ? 'Ride paused. Distance tracking is paused.' : 'Ride resumed.');
  }

  Future<void> _toggleLock() async {
    setState(() => _isLocked = !_isLocked);
    _message(
      _isLocked
          ? 'Ride screen controls are marked locked. This does not lock your phone.'
          : 'Ride screen lock indicator disabled.',
    );
  }

  String _durationText(Duration duration) {
    final hours = duration.inHours.toString().padLeft(2, '0');
    final minutes = (duration.inMinutes % 60).toString().padLeft(2, '0');
    final seconds = (duration.inSeconds % 60).toString().padLeft(2, '0');
    return '$hours:$minutes:$seconds';
  }

  String get _locationLabel {
    final p = _position;
    if (p == null) return _isLoadingLocation ? 'Getting GPS…' : 'No GPS fix';
    return '${p.latitude.toStringAsFixed(5)}, ${p.longitude.toStringAsFixed(5)}';
  }

  Widget _statCard(String title, String value, String unit) {
    return Container(
      height: 91,
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: card,
        borderRadius: BorderRadius.circular(13),
        border: Border.all(color: Colors.white10),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(color: muted, fontSize: 10)),
          const Spacer(),
          FittedBox(
            fit: BoxFit.scaleDown,
            child: Text(
              value,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 19,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          if (unit.isNotEmpty)
            Text(unit, style: const TextStyle(color: muted, fontSize: 10)),
        ],
      ),
    );
  }

  Widget _infoCard(String title, String value, String subtitle) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: card,
          borderRadius: BorderRadius.circular(13),
          border: Border.all(color: Colors.white10),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(color: muted, fontSize: 12)),
            const SizedBox(height: 8),
            Text(
              value,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 5),
            Text(subtitle, style: const TextStyle(color: muted, fontSize: 11)),
          ],
        ),
      ),
    );
  }

  Widget _controlButton({
    required IconData icon,
    required String tooltip,
    required VoidCallback onTap,
    Color color = card,
  }) {
    return IconButton(
      tooltip: tooltip,
      onPressed: onTap,
      iconSize: 24,
      style: IconButton.styleFrom(
        backgroundColor: color,
        foregroundColor: Colors.white,
        side: const BorderSide(color: Colors.white12),
        fixedSize: const Size(48, 48),
      ),
      icon: Icon(icon),
    );
  }

  void _message(String text) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(text),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  @override
  void dispose() {
    _positionSubscription?.cancel();
    _clockTimer?.cancel();
    _mapController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final point = _position == null
        ? null
        : LatLng(_position!.latitude, _position!.longitude);
    final speedAccuracy = _position?.accuracy;
    final speedText = _position == null ? '--' : _speedKmh.toStringAsFixed(0);
    final distanceKm = (_distanceMeters / 1000).toStringAsFixed(2);

    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: bg,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new, color: Colors.white, size: 19),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Live Ride',
          style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w600),
        ),
        centerTitle: true,
        actions: [
          IconButton(
            tooltip: 'Notifications',
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => NotificationsScreen()),
              );
            },
            icon: const Icon(Icons.notifications_active, color: yellow),
          ),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(14, 8, 14, 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(child: _statCard('GPS Speed', speedText, 'km/h')),
                  const SizedBox(width: 8),
                  Expanded(child: _statCard('Trip Distance', distanceKm, 'km')),
                  const SizedBox(width: 8),
                  Expanded(child: _statCard('Ride Time', _durationText(_elapsed), '')),
                ],
              ),
              const SizedBox(height: 14),
              Container(
                height: 285,
                width: double.infinity,
                decoration: BoxDecoration(
                  color: const Color(0xFF101D2A),
                  borderRadius: BorderRadius.circular(17),
                  border: Border.all(color: Colors.white10),
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(17),
                  child: point == null
                      ? Center(
                          child: Padding(
                            padding: const EdgeInsets.all(20),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                if (_isLoadingLocation)
                                  const CircularProgressIndicator(color: yellow)
                                else
                                  const Icon(Icons.location_off, color: yellow, size: 34),
                                const SizedBox(height: 12),
                                Text(
                                  _locationError ?? 'Waiting for a GPS fix…',
                                  textAlign: TextAlign.center,
                                  style: const TextStyle(color: Colors.white),
                                ),
                                const SizedBox(height: 10),
                                OutlinedButton(
                                  onPressed: _startRide,
                                  child: const Text('Retry GPS'),
                                ),
                              ],
                            ),
                          ),
                        )
                      : FlutterMap(
                          mapController: _mapController,
                          options: MapOptions(
                            initialCenter: point,
                            initialZoom: 16,
                            interactionOptions: const InteractionOptions(
                              flags: InteractiveFlag.all,
                            ),
                          ),
                          children: [
                            TileLayer(
                              urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                              userAgentPackageName: 'com.ridershield.app',
                            ),
                            if (_routePoints.length >= 2)
                              PolylineLayer(
                                polylines: [
                                  Polyline(
                                    points: _routePoints,
                                    color: yellow,
                                    strokeWidth: 4,
                                  ),
                                ],
                              ),
                            MarkerLayer(
                              markers: [
                                Marker(
                                  point: point,
                                  width: 48,
                                  height: 48,
                                  child: const Icon(
                                    Icons.my_location,
                                    color: yellow,
                                    size: 34,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                ),
              ),
              const SizedBox(height: 8),
              Text(
                point == null ? 'Current location unavailable' : 'GPS: $_locationLabel',
                style: const TextStyle(color: muted, fontSize: 11),
              ),
              if (_locationError != null) ...[
                const SizedBox(height: 6),
                Text(
                  _locationError!,
                  style: const TextStyle(color: Colors.orangeAccent, fontSize: 12),
                ),
              ],
              const SizedBox(height: 14),
              Row(
                children: [
                  _infoCard(
                    'GPS Accuracy',
                    speedAccuracy == null ? '--' : '${speedAccuracy.toStringAsFixed(0)} m',
                    speedAccuracy == null
                        ? 'Waiting for location'
                        : speedAccuracy <= 20
                            ? 'Good GPS fix'
                            : 'GPS may be imprecise',
                  ),
                  const SizedBox(width: 10),
                  _infoCard(
                    'Helmet Risk',
                    'Unavailable',
                    'Connect helmet sensors to calculate risk',
                  ),
                ],
              ),
              const SizedBox(height: 18),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                 _controlButton(
  icon: Icons.camera_alt_outlined,
  tooltip: 'Open incident camera',
  onTap: () {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => const CameraScreen(),
      ),
    );
  },
),
                  IconButton(
                    tooltip: _isPaused ? 'Resume ride' : 'Pause ride',
                    onPressed: _togglePause,
                    iconSize: 36,
                    style: IconButton.styleFrom(
                      backgroundColor: red,
                      foregroundColor: Colors.white,
                      fixedSize: const Size(62, 62),
                    ),
                    icon: Icon(_isPaused ? Icons.play_arrow_rounded : Icons.pause_rounded),
                  ),
                  _controlButton(
                    icon: _isLocked ? Icons.lock : Icons.lock_outline_rounded,
                    tooltip: _isLocked ? 'Unlock controls' : 'Lock indicator',
                    onTap: _toggleLock,
                    color: _isLocked ? const Color(0xFF193C31) : card,
                  ),
                ],
              ),
              if (_isPaused)
                Container(
                  width: double.infinity,
                  margin: const EdgeInsets.only(top: 16),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: const Color(0xFF39221A),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Text(
                    'RIDE PAUSED — distance tracking is paused',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: yellow, fontWeight: FontWeight.bold),
                  ),
                ),
              const SizedBox(height: 14),
              const Text(
                'Live values come from your phone GPS. Helmet risk/crash detection requires the helmet sensors and is not simulated here.',
                style: TextStyle(color: muted, fontSize: 11, height: 1.4),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: const Color(0xFF08111B),
        currentIndex: 1,
        type: BottomNavigationBarType.fixed,
        selectedItemColor: yellow,
        unselectedItemColor: Colors.white54,
        showUnselectedLabels: true,
        selectedFontSize: 11,
        unselectedFontSize: 11,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home_rounded), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.motorcycle_rounded), label: 'Ride'),
          BottomNavigationBarItem(icon: Icon(Icons.history_rounded), label: 'History'),
          BottomNavigationBarItem(icon: Icon(Icons.person_outline_rounded), label: 'Profile'),
        ],
        onTap: (index) {
          if (index == 0) {
            Navigator.pop(context);
          } else if (index != 1) {
            _message('${['Home', 'Ride', 'History', 'Profile'][index]} navigation must be connected through HomeDashboard.');
          }
        },
      ),
    );
  }
}