
import 'dart:async';

import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import 'alert_sent_screen.dart';

class SendingEmergencyAlertScreen extends StatefulWidget {
  const SendingEmergencyAlertScreen({super.key});

  @override
  State<SendingEmergencyAlertScreen> createState() =>
      _SendingEmergencyAlertScreenState();
}

class _SendingEmergencyAlertScreenState
    extends State<SendingEmergencyAlertScreen> {
  final Color green = const Color(0xFF00D890);
  final Color gold = const Color(0xFFFFC342);
  final Color bg = const Color(0xFF080B12);

  final List<String> titles = [
    'Getting location...',
    'Selecting best network...',
    'Sending emergency packet...',
    'Notifying contacts',
    'Awaiting confirmation',
  ];

  final List<String> details = [
    '27.1767, 78.0081',
    'Phone Network\nNot available',
    'RiderShield Network (LoRa)\nConnected',
    'Emergency contacts are being notified',
    'Waiting for delivery confirmation',
  ];

  int currentStep = 0;

  @override
  void initState() {
    super.initState();
    _startProgress();
  }

  Future<void> _startProgress() async {
    for (int step = 0; step < titles.length; step++) {
      await Future.delayed(const Duration(seconds: 2));

      if (!mounted) return;

      setState(() {
        currentStep = step + 1;
      });
    }

    await Future.delayed(const Duration(seconds: 1));

    if (!mounted) return;

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => const AlertSentScreen(),
      ),
    );
  }

  Future<void> _call112() async {
    final uri = Uri(scheme: 'tel', path: '112');

    try {
      final launched = await launchUrl(uri);

      if (!launched && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Unable to open phone dialer.'),
          ),
        );
      }
    } catch (_) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Unable to open phone dialer.'),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: bg,
        foregroundColor: Colors.white,
        elevation: 0,
        title: const Text(
          'Sending Emergency Alert',
          style: TextStyle(fontSize: 17),
        ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(22),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 18),
                    ...List.generate(titles.length, (index) {
                      final bool completed = index < currentStep;
                      final bool active = index == currentStep;

                      return IntrinsicHeight(
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            SizedBox(
                              width: 28,
                              child: Column(
                                children: [
                                  Container(
                                    width: 23,
                                    height: 23,
                                    decoration: BoxDecoration(
                                      color: completed || active
                                          ? green
                                          : const Color(0xFF26303D),
                                      shape: BoxShape.circle,
                                    ),
                                    child: Icon(
                                      completed
                                          ? Icons.check
                                          : active
                                              ? Icons.sync
                                              : Icons.circle,
                                      size: 14,
                                      color: completed || active
                                          ? Colors.black
                                          : Colors.white54,
                                    ),
                                  ),
                                  if (index != titles.length - 1)
                                    Expanded(
                                      child: Container(
                                        width: 2,
                                        color: completed
                                            ? green
                                            : const Color(0xFF26303D),
                                      ),
                                    ),
                                ],
                              ),
                            ),
                            const SizedBox(width: 14),
                            Expanded(
                              child: Padding(
                                padding: const EdgeInsets.only(
                                  bottom: 27,
                                  top: 1,
                                ),
                                child: Column(
                                  crossAxisAlignment:
                                      CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      titles[index],
                                      style: TextStyle(
                                        color: active || completed
                                            ? Colors.white
                                            : Colors.white60,
                                        fontSize: 14,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                    const SizedBox(height: 9),
                                    Text(
                                      details[index],
                                      style: TextStyle(
                                        color: active
                                            ? gold
                                            : Colors.white60,
                                        fontSize: 12,
                                        height: 1.6,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      );
                    }),
                  ],
                ),
              ),
            ),
            Container(
              margin: const EdgeInsets.fromLTRB(18, 8, 18, 20),
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: const Color(0xFF101722),
                borderRadius: BorderRadius.circular(15),
                border: Border.all(
                  color: const Color(0xFF26303D),
                ),
              ),
              child: Column(
                children: [
                  Icon(
                    Icons.shield_outlined,
                    color: green,
                    size: 30,
                  ),
                  const SizedBox(height: 10),
                  const Text(
                    'Emergency alert in progress',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Your alert is being processed through the '
                    'available network.',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.white60,
                      fontSize: 12,
                      height: 1.5,
                    ),
                  ),
                  const SizedBox(height: 18),
                  SizedBox(
                    width: double.infinity,
                    height: 48,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: gold,
                        foregroundColor: Colors.black,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(11),
                        ),
                      ),
                      child: const Text('Back'),
                    ),
                  ),
                  const SizedBox(height: 12),
                  SizedBox(
                    width: double.infinity,
                    height: 48,
                    child: OutlinedButton.icon(
                      onPressed: _call112,
                      icon: const Icon(Icons.call),
                      label: const Text('Call Emergency Number 112'),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: green,
                        side: BorderSide(color: green),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(11),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

