import 'dart:async';
import 'package:flutter/material.dart';
import 'sending_emergency_alert_screen.dart';

class EmergencyActivatedScreen extends StatefulWidget {
  const EmergencyActivatedScreen({super.key});

  @override
  State<EmergencyActivatedScreen> createState() =>
      _EmergencyActivatedScreenState();
}

class _EmergencyActivatedScreenState
    extends State<EmergencyActivatedScreen> {
  bool cancelled = false;
  Timer? _cancelTimer;
  int _remainingSeconds = 10;
  final List<String> steps = [
    'Crash detected',
    'No response from rider',
    'Location acquired',
    'Communication route selected',
    'Emergency contacts notified',
  ];

  bool _navigating = false;

  @override
  void initState() {
    super.initState();
    // Give the rider 10 seconds to cancel; otherwise continue automatically.
    _cancelTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted || cancelled || _navigating) {
        timer.cancel();
        return;
      }

      if (_remainingSeconds <= 1) {
        timer.cancel();
        _continueToEmergencyAlert();
      } else {
        setState(() {
          _remainingSeconds--;
        });
      }
    });
  }

  void _continueToEmergencyAlert() {
    if (!mounted || cancelled || _navigating) return;
    _navigating = true;
    _cancelTimer?.cancel();
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => SendingEmergencyAlertScreen(),
      ),
    );
  }

  @override
  void dispose() {
    _cancelTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF080A10),
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 430),
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(
                horizontal: 22,
                vertical: 18,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  const SizedBox(height: 8),

                  // Rider Shield logo
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: const [
                      Icon(
                        Icons.shield_outlined,
                        color: Color(0xFFFFC342),
                        size: 24,
                      ),
                      SizedBox(width: 7),
                      Text(
                        'RIDER',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                      ),
                      Text(
                        ' SHIELD',
                        style: TextStyle(
                          color: Color(0xFFFFC342),
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 35),

                  // Emergency icon
                  Container(
                    height: 130,
                    width: 130,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: const Color(0xFF42151B).withValues(alpha: 0.4),
                      border: Border.all(
                        color: const Color(0xFF81262D).withValues(alpha: 0.4),
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0xFFFF303D)
                              .withValues(alpha: 0.10),
                          blurRadius: 35,
                          spreadRadius: 10,
                        ),
                      ],
                    ),
                    child: const Icon(
                      Icons.notifications_active,
                      color: Color(0xFFFF4D57),
                      size: 67,
                    ),
                  ),

                  const SizedBox(height: 22),

                  const Text(
                    'EMERGENCY\nACTIVATED',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Color(0xFFFF626B),
                      fontSize: 27,
                      height: 1.2,
                      fontWeight: FontWeight.bold,
                    ),
                  ),

                  const SizedBox(height: 28),

                  // Status checklist
                  ...steps.map(
                    (step) => Padding(
                      padding: const EdgeInsets.only(bottom: 15),
                      child: Row(
                        children: [
                          const Icon(
                            Icons.check_circle,
                            color: Color(0xFF18D58A),
                            size: 20,
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Text(
                              step,
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 14,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                  const SizedBox(height: 12),

                  // Alert recipients card
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: const Color(0xFF151923),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: const Color(0xFF303441),
                      ),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Sending alerts to',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 13,
                          ),
                        ),
                        const SizedBox(height: 20),
                        Row(
                          children: [
                            recipient(
                              Icons.person,
                              'Family',
                              'Mom',
                            ),
                            recipient(
                              Icons.health_and_safety,
                              'Company',
                              'Safety Team',
                            ),
                            recipient(
                              Icons.favorite,
                              'Emergency',
                              'Support',
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 22),

                  // Cancel button
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      onPressed: cancelled
                          ? null
                          : () {
                              _cancelTimer?.cancel();
                              setState(() {
                                cancelled = true;
                              });

                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  content: Text(
                                    'Automatic emergency continuation cancelled.',
                                  ),
                                ),
                              );
                            },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF851E24),
                        foregroundColor: const Color(0xFFFF7777),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                          side: const BorderSide(
                            color: Color(0xFFB52D35),
                          ),
                        ),
                      ),
                      child: Text(
                        cancelled ? 'Alert Cancelled' : 'Cancel ($_remainingSeconds s)',
                        style: const TextStyle(fontSize: 15),
                      ),
                    ),
                  ),

                  const SizedBox(height: 15),
SizedBox(
  width: double.infinity,
  height: 48,
  child: ElevatedButton(
    onPressed: _continueToEmergencyAlert,
    style: ElevatedButton.styleFrom(
      backgroundColor: const Color(0xFFFFC342),
      foregroundColor: Colors.black,
    ),
    child: const Text('Continue to Emergency Alert'),
  ),
),

const SizedBox(height: 15),


                  const Text(
                    'Emergency contacts can be notified automatically '
                    'when a rider does not respond.',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Color(0xFF9298A5),
                      fontSize: 11,
                      height: 1.6,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget recipient(IconData icon, String title, String subtitle) {
    return Expanded(
      child: Column(
        children: [
          Icon(
            icon,
            color: const Color(0xFFFF4D57),
            size: 29,
          ),
          const SizedBox(height: 9),
          Text(
            title,
            textAlign: TextAlign.center,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 11,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            subtitle,
            textAlign: TextAlign.center,
            style: const TextStyle(
              color: Color(0xFFB5BAC5),
              fontSize: 10,
            ),
          ),
        ],
      ),
    );
  }
}