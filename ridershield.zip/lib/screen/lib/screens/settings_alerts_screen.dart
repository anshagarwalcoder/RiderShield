import 'package:flutter/material.dart';

class SettingsAlertsScreen extends StatefulWidget {
  const SettingsAlertsScreen({super.key});

  @override
  State<SettingsAlertsScreen> createState() =>
      _SettingsAlertsScreenState();
}

class _SettingsAlertsScreenState
    extends State<SettingsAlertsScreen> {
  static const Color bg = Color(0xFF05080F);
  static const Color card = Color(0xFF101722);
  static const Color border = Color(0xFF26303D);
  static const Color muted = Color(0xFF9CA6B5);
  static const Color gold = Color(0xFFFFC342);
  static const Color green = Color(0xFF00D890);
  static const Color red = Color(0xFFFF454A);

  bool autoAlerts = true;
  bool liveLocation = true;
  bool notifyCompany = true;
  bool voiceAlert = true;

  String sensitivity = 'Medium';

  final List<Map<String, String>> contacts = [
    {
      'name': 'Mom (Primary)',
      'phone': '+91 9876543210',
      'initial': 'M',
    },
    {
      'name': 'Dad (Secondary)',
      'phone': '+91 9123456780',
      'initial': 'D',
    },
  ];

  void showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  void addContact() {
    final nameController = TextEditingController();
    final phoneController = TextEditingController();

    showDialog(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          backgroundColor: card,
          title: const Text(
            'Add Emergency Contact',
            style: TextStyle(color: Colors.white),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: nameController,
                style: const TextStyle(color: Colors.white),
                decoration: const InputDecoration(
                  hintText: 'Contact name',
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: phoneController,
                keyboardType: TextInputType.phone,
                style: const TextStyle(color: Colors.white),
                decoration: const InputDecoration(
                  hintText: 'Phone number',
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                final name = nameController.text.trim();
                final phone = phoneController.text.trim();

                if (name.isEmpty || phone.isEmpty) {
                  showMessage('Please enter name and phone number');
                  return;
                }

                setState(() {
                  contacts.add({
                    'name': name,
                    'phone': phone,
                    'initial': name[0].toUpperCase(),
                  });
                });

                Navigator.pop(dialogContext);
                showMessage('Contact added successfully');
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: gold,
                foregroundColor: Colors.black,
              ),
              child: const Text('Add'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: bg,
        foregroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new, size: 19),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Alert Preferences',
          style: TextStyle(fontSize: 17),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(18, 8, 18, 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Emergency Contacts',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 15,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 13),

              Container(
                decoration: BoxDecoration(
                  color: card,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: border),
                ),
                child: Column(
                  children: [
                    for (int i = 0; i < contacts.length; i++) ...[
                      ListTile(
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 3,
                        ),
                        leading: CircleAvatar(
                          radius: 20,
                          backgroundColor: const Color(0xFF293F75),
                          child: Text(
                            contacts[i]['initial']!,
                            style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        title: Text(
                          contacts[i]['name']!,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        subtitle: Padding(
                          padding: const EdgeInsets.only(top: 5),
                          child: Text(
                            contacts[i]['phone']!,
                            style: const TextStyle(
                              color: muted,
                              fontSize: 11,
                            ),
                          ),
                        ),
                        trailing: const Icon(
                          Icons.chevron_right,
                          color: muted,
                        ),
                        onTap: () => showMessage(
                          '${contacts[i]['name']} selected',
                        ),
                      ),
                      if (i != contacts.length - 1)
                        const Divider(
                          height: 1,
                          color: border,
                          indent: 14,
                          endIndent: 14,
                        ),
                    ],
                    Padding(
                      padding: const EdgeInsets.fromLTRB(12, 5, 12, 12),
                      child: SizedBox(
                        width: double.infinity,
                        height: 43,
                        child: OutlinedButton.icon(
                          onPressed: addContact,
                          icon: const Icon(Icons.add, size: 18),
                          label: const Text('Add Contact'),
                          style: OutlinedButton.styleFrom(
                            foregroundColor: Colors.white,
                            side: const BorderSide(color: border),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 27),

              const Text(
                'Alert Settings',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 15,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 10),

              Container(
                decoration: BoxDecoration(
                  color: card,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: border),
                ),
                child: Column(
                  children: [
                    settingSwitch(
                      icon: Icons.notifications_active,
                      title: 'Auto Emergency Alerts',
                      value: autoAlerts,
                      color: red,
                      onChanged: (value) {
                        setState(() => autoAlerts = value);
                      },
                    ),
                    settingDivider(),
                    settingSwitch(
                      icon: Icons.location_on,
                      title: 'Send Live Location',
                      value: liveLocation,
                      color: green,
                      onChanged: (value) {
                        setState(() => liveLocation = value);
                      },
                    ),
                    settingDivider(),
                    settingSwitch(
                      icon: Icons.business,
                      title: 'Notify Company',
                      value: notifyCompany,
                      color: const Color(0xFF668BFF),
                      onChanged: (value) {
                        setState(() => notifyCompany = value);
                      },
                    ),
                    settingDivider(),
                    settingSwitch(
                      icon: Icons.record_voice_over,
                      title: 'Voice Alert in Helmet',
                      value: voiceAlert,
                      color: red,
                      onChanged: (value) {
                        setState(() => voiceAlert = value);
                      },
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 27),

              const Text(
                'Crash Sensitivity',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 15,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 13),

              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: card,
                  borderRadius: BorderRadius.circular(13),
                  border: Border.all(color: border),
                ),
                child: Row(
                  children: [
                    sensitivityButton('Low'),
                    sensitivityButton('Medium'),
                    sensitivityButton('High'),
                  ],
                ),
              ),

              const SizedBox(height: 14),

              const Text(
                'Choose how sensitive the crash detection system '
                'should be.',
                style: TextStyle(
                  color: muted,
                  fontSize: 11,
                  height: 1.5,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget settingSwitch({
    required IconData icon,
    required String title,
    required bool value,
    required Color color,
    required ValueChanged<bool> onChanged,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: 13,
        vertical: 3,
      ),
      child: Row(
        children: [
          Icon(icon, color: color, size: 20),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              title,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 12,
              ),
            ),
          ),
          Switch(
            value: value,
            onChanged: onChanged,
            activeThumbColor: Colors.white,
            activeTrackColor: green,
            inactiveThumbColor: Colors.white70,
            inactiveTrackColor: const Color(0xFF374151),
          ),
        ],
      ),
    );
  }

  Widget settingDivider() {
    return const Divider(
      height: 1,
      color: border,
      indent: 13,
      endIndent: 13,
    );
  }

  Widget sensitivityButton(String label) {
    final bool selected = sensitivity == label;

    return Expanded(
      child: GestureDetector(
        onTap: () {
          setState(() => sensitivity = label);
        },
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: selected
                ? (label == 'Medium'
                    ? const Color(0xFF087F59)
                    : gold)
                : Colors.transparent,
            borderRadius: BorderRadius.circular(9),
          ),
          child: Text(
            label,
            textAlign: TextAlign.center,
            style: TextStyle(
              color: selected
                  ? (label == 'Medium' ? Colors.white : Colors.black)
                  : muted,
              fontSize: 12,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      ),
    );
  }
}