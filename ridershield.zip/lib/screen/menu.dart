import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'login_screen.dart';

const Color bg = Color(0xFF05090F);
const Color card = Color(0xFF101722);
const Color borderColor = Color(0xFF26303D);
const Color gold = Color(0xFFFFC629);
const Color muted = Color(0xFFB7C0CE);
const Color danger = Color(0xFFE52F32);

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  User? get user => FirebaseAuth.instance.currentUser;

  DocumentReference<Map<String, dynamic>>? get userDoc {
    final currentUser = user;
    if (currentUser == null) return null;

    return FirebaseFirestore.instance
        .collection('users')
        .doc(currentUser.uid);
  }

  void message(String text) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          text,
          style: const TextStyle(color: Colors.white),
        ),
        backgroundColor: card,
      ),
    );
  }

  Future<void> editProfile(Map<String, dynamic> data) async {
    final currentUser = user;
    final doc = userDoc;

    if (currentUser == null || doc == null) return;

    final nameController = TextEditingController(
      text: data['name'] ?? currentUser.displayName ?? '',
    );
    final phoneController = TextEditingController(
      text: data['phone'] ?? '',
    );

    final savedContacts = data['emergencyContacts'];
    final contacts = <TextEditingController>[];

    if (savedContacts is List && savedContacts.isNotEmpty) {
      for (final contact in savedContacts) {
        contacts.add(TextEditingController(text: contact.toString()));
      }
    } else {
      contacts.add(TextEditingController());
    }

    var saving = false;

    try {
      await showDialog(
        context: context,
        barrierDismissible: false,
        builder: (dialogContext) => StatefulBuilder(
          builder: (context, setDialogState) => AlertDialog(
            backgroundColor: card,
            title: const Text(
              'Edit Profile',
              style: TextStyle(color: Colors.white),
            ),
            content: SizedBox(
              width: 400,
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    editField(nameController, 'Full name'),
                    const SizedBox(height: 12),
                    editField(
                      phoneController,
                      'Phone number',
                      type: TextInputType.phone,
                    ),
                    const SizedBox(height: 18),
                    const Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        'Emergency Contacts',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    ...List.generate(contacts.length, (index) {
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: Row(
                          children: [
                            Expanded(
                              child: editField(
                                contacts[index],
                                'Contact ${index + 1} number',
                                type: TextInputType.phone,
                              ),
                            ),
                            IconButton(
                              onPressed: contacts.length == 1
                                  ? null
                                  : () {
                                      setDialogState(() {
                                        contacts[index].dispose();
                                        contacts.removeAt(index);
                                      });
                                    },
                              icon: const Icon(
                                Icons.remove_circle_outline,
                                color: Colors.redAccent,
                              ),
                            ),
                          ],
                        ),
                      );
                    }),
                    TextButton.icon(
                      onPressed: contacts.length >= 5
                          ? null
                          : () => setDialogState(
                                () => contacts.add(
                                  TextEditingController(),
                                ),
                              ),
                      icon: const Icon(Icons.add),
                      label: const Text('Add another contact'),
                    ),
                  ],
                ),
              ),
            ),
            actions: [
              TextButton(
                onPressed: saving
                    ? null
                    : () => Navigator.pop(dialogContext),
                child: const Text('Cancel'),
              ),
              ElevatedButton(
                onPressed: saving
                    ? null
                    : () async {
                        final name = nameController.text.trim();
                        final phone = phoneController.text.trim();

                        final numbers = contacts
                            .map((c) => c.text.trim())
                            .where((n) => n.isNotEmpty)
                            .toList();

                        if (name.isEmpty) {
                          message('Please enter your name.');
                          return;
                        }

                        if (numbers.any(
                          (n) =>
                              n.replaceAll(RegExp(r'\D'), '').length < 10,
                        )) {
                          message('Please check the emergency numbers.');
                          return;
                        }

                        setDialogState(() => saving = true);

                        try {
                          await doc.set({
                            'name': name,
                            'phone': phone,
                            'emergencyContacts': numbers,
                          }, SetOptions(merge: true));

                          await currentUser.updateDisplayName(name);

                          if (dialogContext.mounted) {
                            Navigator.pop(dialogContext);
                          }

                          message('Profile saved successfully.');
                        } catch (e) {
                          setDialogState(() => saving = false);
                          message('Save failed: $e');
                        }
                      },
                style: ElevatedButton.styleFrom(
                  backgroundColor: gold,
                  foregroundColor: Colors.black,
                ),
                child: Text(saving ? 'Saving...' : 'Save'),
              ),
            ],
          ),
        ),
      );
    } finally {
      nameController.dispose();
      phoneController.dispose();
      for (final controller in contacts) {
        controller.dispose();
      }
    }
  }

  Widget editField(
    TextEditingController controller,
    String label, {
    TextInputType type = TextInputType.text,
  }) {
    return TextField(
      controller: controller,
      keyboardType: type,
      style: const TextStyle(color: Colors.white),
      cursorColor: gold,
      decoration: InputDecoration(
        labelText: label,
        labelStyle: const TextStyle(color: muted),
        filled: true,
        fillColor: bg,
        enabledBorder: OutlineInputBorder(
          borderSide: const BorderSide(color: borderColor),
          borderRadius: BorderRadius.circular(10),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: const BorderSide(color: gold),
          borderRadius: BorderRadius.circular(10),
        ),
      ),
    );
  }

  Future<void> showInfo(String title, String text) async {
    await showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: card,
        title: Text(
          title,
          style: const TextStyle(color: Colors.white),
        ),
        content: Text(
          text,
          style: const TextStyle(color: muted, height: 1.5),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  Future<void> logout() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: card,
        title: const Text(
          'Log Out?',
          style: TextStyle(color: Colors.white),
        ),
        content: const Text(
          'Are you sure you want to log out?',
          style: TextStyle(color: muted),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text(
              'Log Out',
              style: TextStyle(color: Colors.redAccent),
            ),
          ),
        ],
      ),
    );

    if (confirm != true) return;

    await FirebaseAuth.instance.signOut();
    if (!mounted) return;

    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const LoginScreen()),
      (route) => false,
    );
  }

  Widget panel(Widget child) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: card,
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: borderColor),
      ),
      child: child,
    );
  }

  Widget menuTile(
    IconData icon,
    String title,
    VoidCallback onTap, {
    bool last = false,
    String? subtitle,
  }) {
    return Column(
      children: [
        ListTile(
          contentPadding: const EdgeInsets.symmetric(horizontal: 2),
          leading: Icon(icon, color: muted),
          title: Text(
            title,
            style: const TextStyle(color: Colors.white, fontSize: 14),
          ),
          subtitle: subtitle == null
              ? null
              : Text(
                  subtitle,
                  style: const TextStyle(color: muted, fontSize: 11),
                ),
          trailing: const Icon(
            Icons.chevron_right,
            color: muted,
          ),
          onTap: onTap,
        ),
        if (!last) const Divider(color: borderColor, height: 1),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final currentUser = user;
    final doc = userDoc;

    if (currentUser == null || doc == null) {
      return const Scaffold(
        backgroundColor: bg,
        body: Center(
          child: Text(
            'Please log in again.',
            style: TextStyle(color: Colors.white),
          ),
        ),
      );
    }

    return Theme(
      data: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: bg,
        textTheme: ThemeData.dark().textTheme.apply(
          bodyColor: Colors.white,
          displayColor: Colors.white,
        ),
      ),
      child: Scaffold(
        backgroundColor: bg,
        body: SafeArea(
          child: StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
            stream: doc.snapshots(),
            builder: (context, snapshot) {
              if (snapshot.hasError) {
                return Center(
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Text(
                      'Profile load failed.\n${snapshot.error}',
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        color: Colors.orangeAccent,
                      ),
                    ),
                  ),
                );
              }

              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(
                  child: CircularProgressIndicator(color: gold),
                );
              }

              final data = snapshot.data?.data() ?? <String, dynamic>{};
              final storedName = (data['name'] as String?)?.trim() ?? '';
              final authName = currentUser.displayName?.trim() ?? '';
              final name = storedName.isNotEmpty
                  ? storedName
                  : authName.isNotEmpty
                      ? authName
                      : 'Rider';

              final phone = (data['phone'] as String?)?.trim() ?? '';
              final raw = data['emergencyContacts'];
              final numbers = raw is List
                  ? raw
                      .map((item) => item.toString().trim())
                      .where((item) => item.isNotEmpty)
                      .toList()
                  : <String>[];

              final uid = currentUser.uid;
              final riderId = uid.substring(
                0,
                uid.length < 8 ? uid.length : 8,
              );

              return SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(18, 12, 18, 28),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Expanded(
                          child: Text(
                            'Profile',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 26,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        IconButton(
                          onPressed: () => showInfo(
                            'Settings',
                            'Use the options below to view RiderShield settings.',
                          ),
                          icon: const Icon(
                            Icons.settings_outlined,
                            color: Colors.white,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 14),
                    panel(
                      Row(
                        children: [
                          CircleAvatar(
                            radius: 27,
                            backgroundColor: const Color(0xFF263F78),
                            child: Text(
                              name[0].toUpperCase(),
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 24,
                              ),
                            ),
                          ),
                          const SizedBox(width: 13),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  name,
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 17,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                                const SizedBox(height: 5),
                                Text(
                                  phone.isEmpty ? 'Phone not saved' : phone,
                                  style: const TextStyle(
                                    color: muted,
                                    fontSize: 12,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  'Rider ID: $riderId',
                                  style: const TextStyle(
                                    color: muted,
                                    fontSize: 11,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          IconButton(
                            tooltip: 'Edit profile',
                            onPressed: () => editProfile(data),
                            icon: const Icon(Icons.edit, color: gold),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                    panel(
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              const Expanded(
                                child: Text(
                                  'Emergency Contacts',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 15,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ),
                              TextButton.icon(
                                onPressed: () => editProfile(data),
                                icon: const Icon(Icons.edit, size: 16),
                                label: const Text('Edit'),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          if (numbers.isEmpty)
                            const Text(
                              'No emergency contacts saved yet. Tap Edit to add them.',
                              style: TextStyle(color: muted, fontSize: 13),
                            )
                          else
                            ...List.generate(numbers.length, (index) {
                              return Padding(
                                padding: const EdgeInsets.symmetric(
                                  vertical: 8,
                                ),
                                child: Row(
                                  children: [
                                    const Icon(
                                      Icons.contact_phone_outlined,
                                      color: gold,
                                      size: 21,
                                    ),
                                    const SizedBox(width: 12),
                                    Expanded(
                                      child: Text(
                                        'Contact ${index + 1}',
                                        style: const TextStyle(
                                          color: Colors.white,
                                        ),
                                      ),
                                    ),
                                    Text(
                                      numbers[index],
                                      style: const TextStyle(
                                        color: muted,
                                        fontSize: 13,
                                      ),
                                    ),
                                  ],
                                ),
                              );
                            }),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                    panel(
                      Column(
                        children: [
                          menuTile(
                            Icons.shield_outlined,
                            'Helmet Settings',
                            () => showInfo(
                              'Helmet Settings',
                              'Hardware controls will be connected during hardware integration.',
                            ),
                          ),
                          menuTile(
                            Icons.notifications_none,
                            'Alert Preferences',
                            () => showInfo(
                              'Alert Preferences',
                              'Emergency contact numbers are stored in your profile. Real SMS/calls are not implemented yet.',
                            ),
                          ),
                          menuTile(
                            Icons.wifi_off_outlined,
                            'Offline Mode',
                            () => showInfo(
                              'Offline Mode',
                              'Offline relay networking will be configured during hardware integration.',
                            ),
                            subtitle: 'Hardware relay not connected yet',
                          ),
                          menuTile(
                            Icons.help_outline,
                            'Help & Support',
                            () => showInfo(
                              'Help & Support',
                              'Check your internet connection and Firebase sign-in if your profile does not load.',
                            ),
                          ),
                          menuTile(
                            Icons.info_outline,
                            'About RiderShield',
                            () => showInfo(
                              'About RiderShield',
                              'RiderShield is a rider safety app with profile management and crash-event logging.',
                            ),
                            last: true,
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 18),
                    SizedBox(
                      width: double.infinity,
                      height: 50,
                      child: ElevatedButton.icon(
                        onPressed: logout,
                        icon: const Icon(Icons.logout),
                        label: const Text(
                          'Log Out',
                          style: TextStyle(fontWeight: FontWeight.w600),
                        ),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: danger,
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}