
import 'package:flutter/material.dart';
import 'onboarding_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();

    Future.delayed(const Duration(seconds: 2), () {
      if (!mounted) return;

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => const OnboardingScreen(),
        ),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF05090F),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(
              Icons.shield_rounded,
              color: Color(0xFFFFC629),
              size: 90,
            ),
            const SizedBox(height: 16),
            const Text(
              'RIDER SHIELD',
              style: TextStyle(
                color: Colors.white,
                fontSize: 30,
                fontWeight: FontWeight.bold,
                letterSpacing: 2,
              ),
            ),
            const SizedBox(height: 10),
            const Text(
              'RIDE TODAY. SAFER TOMORROW.',
              style: TextStyle(
                color: Color(0xFFFFC629),
                fontSize: 11,
                letterSpacing: 2,
              ),
            ),
            const SizedBox(height: 30),
            const SizedBox(
              width: 100,
              child: LinearProgressIndicator(
                color: Color(0xFFFFC629),
                backgroundColor: Color(0xFF26303C),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
