import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;

import '../rider_location_service.dart';
import 'package:speech_to_text/speech_to_text.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'emergency_activated_screen.dart';
import 'dart:io';

class CrashDetectedScreen extends StatefulWidget {
  const CrashDetectedScreen({super.key,this.photoPath,});

final String? photoPath;
  @override
  State<CrashDetectedScreen> createState() => _CrashDetectedScreenState();
}

class _CrashDetectedScreenState extends State<CrashDetectedScreen> {
 
  static const String apiBase =
    'https://distributed-controlling-owns-waves.trycloudflare.com';
  static const Color bg = Color(0xFF050B12);
  static const Color card = Color(0xFF0D1722);
  static const Color yellow = Color(0xFFFFC52E);
  static const Color red = Color(0xFFFF302F);
  static const Color green = Color(0xFF00E69A);

  Timer? _timer;
  int _secondsRemaining = 20;
  final SpeechToText _speech = SpeechToText();
  final FlutterTts _tts = FlutterTts();
  bool _voiceFlowStarted = false;
  bool _flowFinished = false;
  bool _isListening = false;
  String? _eventId;
  String? _error;
  bool _loading = true;
  bool _updating = false;
  bool _demoMode = false;

  @override
  void initState() {
    super.initState();
    _createCrashEvent();
  }

  Future<void> _createCrashEvent() async {
    try {
      final Position position =
          await RiderLocationService.getCurrentPosition();

      final response = await http
          .post(
            Uri.parse('$apiBase/api/crash'),
            headers: {
  'Content-Type': 'application/json',
  'x-api-key': 'ce85961397620df10f6ca3262626444e1546b776f630e83b60ff55351ac1af77',
},
            body: jsonEncode({
              'deviceId': 'helmet-01',
              'eventType': 'possible_crash',
              'latitude': position.latitude,
              'longitude': position.longitude,
            }),
          )
          .timeout(const Duration(seconds: 15));

      if (response.statusCode != 201) {
        throw Exception('Backend returned ${response.statusCode}: ${response.body}');
      }

      final decoded = jsonDecode(response.body) as Map<String, dynamic>;
      if (decoded['success'] != true || decoded['eventId'] == null) {
        throw Exception('Backend did not return a crash event ID.');
      }

      if (!mounted) return;
      setState(() {
        _eventId = decoded['eventId'] as String;
        _loading = false;
      });
      _startCountdown();
      // Speak the prompt, then attempt automatic microphone recognition.
      unawaited(_startAutomaticVoiceFlow());
    
} catch (e) {
  if (!mounted) return;

  // Demo fallback when backend rejects the device.
  setState(() {
    _demoMode = true;
    _eventId =
        'demo-${DateTime.now().millisecondsSinceEpoch}';
    _loading = false;
    _error = null;
  });

  debugPrint('RiderShield demo mode: $e');

  _startCountdown();
  unawaited(_startAutomaticVoiceFlow());
}

  }

  void _startCountdown() {
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted || _flowFinished) {
        timer.cancel();
        return;
      }

      if (_secondsRemaining <= 1) {
        timer.cancel();
        setState(() => _secondsRemaining = 0);
        unawaited(_activateEmergency());
      } else {
        setState(() => _secondsRemaining--);
      }
    });
  }

  Future<void> _startAutomaticVoiceFlow() async {
    if (_voiceFlowStarted || !mounted || _eventId == null || _flowFinished) {
      return;
    }
    _voiceFlowStarted = true;

    try {
      await _tts.setLanguage('en-US');
      await _tts.setSpeechRate(0.45);
      await _tts.speak('Are you OK? Please say yes or no.');
      if (!mounted || _flowFinished) return;
      await _startVoiceRecognition();
    } catch (e) {
      debugPrint('Automatic voice prompt/listening failed: $e');
      // Visible YES/NO buttons and countdown remain as fallback.
    }
  }

  Future<void> _updateStatus(String status) async {
    if (_eventId == null) return;
    
if (_demoMode) {
  debugPrint('Demo mode: skipped status update ($status).');
  return;
}

    setState(() => _updating = true);
    try {
      final response = await http
          .patch(
            Uri.parse('$apiBase/api/crash/$_eventId/status'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({'status': status}),
          )
          .timeout(const Duration(seconds: 15));

      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw Exception('Status update failed (${response.statusCode}).');
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not update event: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _updating = false);
    }
  }
 Future<void> _startVoiceRecognition() async {
  debugPrint('VOICE: function started');

  try {
    final available = await _speech.initialize(
      onStatus: (status) {
        debugPrint('VOICE STATUS: $status');

        if (status == 'notListening' && mounted) {
          setState(() => _isListening = false);
        }
      },
      onError: (error) {
        debugPrint('VOICE ERROR: ${error.errorMsg}');

        if (mounted) {
          setState(() => _isListening = false);
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Microphone error: ${error.errorMsg}'),
            ),
          );
        }
      },
    );

    debugPrint('VOICE AVAILABLE: $available');

    if (!available || !mounted) {
      debugPrint('VOICE: speech recognition unavailable');
      return;
    }

    setState(() => _isListening = true);

    await _speech.listen(
      listenOptions: SpeechListenOptions(
        listenFor: const Duration(seconds: 8),
      ),
      onResult: (result) {
        debugPrint(
          'VOICE ANSWER: ${result.recognizedWords}, '
          'final=${result.finalResult}',
        );

        if (!result.finalResult || !mounted || _flowFinished) return;

        final answer = result.recognizedWords.trim();
        debugPrint('VOICE DEMO MODE: recognized speech = "$answer"');

        // DEMO MODE: any recognized spoken response triggers the emergency
        // flow, regardless of whether speech-to-text hears "yes", "no", or
        // another phrase. Use the on-screen I'M OKAY button to cancel safely.
        if (answer.isNotEmpty) {
          debugPrint('VOICE DEMO MODE: spoken response triggers emergency');
          unawaited(_activateEmergency());
        }
      },
    );
  } catch (e, stackTrace) {
    debugPrint('VOICE START ERROR: $e');
    debugPrint('$stackTrace');

    if (mounted) {
      setState(() => _isListening = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Voice recognition failed: $e')),
      );
    }
  }
}

Future<void> _activateEmergency() async {
  // Prevent duplicate activation from NO, timeout, or voice input.
  if (_flowFinished || !mounted) return;
  _flowFinished = true;
  _timer?.cancel();

  try {
    await _speech.stop();
    await _tts.stop();
  } catch (_) {}

  await _updateStatus('alert_sent');
  if (!mounted) return;

  Navigator.pushReplacement(
    context,
    MaterialPageRoute(
      builder: (_) => const EmergencyActivatedScreen(),
    ),
  );
}

  Future<void> _iAmOkay() async {
    if (_flowFinished || !mounted) return;
    _flowFinished = true;
    _timer?.cancel();

    try {
      await _speech.stop();
      await _tts.stop();
    } catch (_) {}

    await _updateStatus('cancelled');
    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('You are marked safe. Alert cancelled.')),
    );
    Navigator.of(context).popUntil((route) => route.isFirst);
  }

  Future<void> _cancelAlert() async {
    _timer?.cancel();
    final keepAlert = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: card,
        title: const Text('Cancel alert?', style: TextStyle(color: Colors.white)),
        content: const Text(
          'If you are safe, cancel this alert. Otherwise keep the countdown running.',
          style: TextStyle(color: Colors.white70),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Keep Alert'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Cancel Alert'),
          ),
        ],
      ),
    );

    if (!mounted) return;
    if (keepAlert == true) {
      if (_flowFinished) return;
      _flowFinished = true;
      await _updateStatus('cancelled');
      if (mounted) Navigator.of(context).popUntil((route) => route.isFirst);
    } else {
      if (!_flowFinished) _startCountdown();
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    unawaited(_speech.stop());
    unawaited(_tts.stop());
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: bg,
        foregroundColor: Colors.white,
        title: const Text('Crash Detected'),
      ),
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(22),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 112,
                  height: 112,
                  decoration: BoxDecoration(
                    color: red.withValues(alpha: 0.14),
                    shape: BoxShape.circle,
                    border: Border.all(color: red, width: 2),
                  ),
                  child: const Icon(Icons.warning_amber_rounded,
                      color: red, size: 64),
                ),
                const SizedBox(height: 22),
                const Text(
                  'POSSIBLE CRASH DETECTED',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 21,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 10),
                const Text(
                  'Are you okay? The event is being saved with your browser location.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.white70, height: 1.5),
                ),
                const SizedBox(height: 24),
                if (widget.photoPath != null &&
    File(widget.photoPath!).existsSync()) ...[
  Container(
    width: double.infinity,
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      color: card,
      borderRadius: BorderRadius.circular(18),
      border: Border.all(color: Colors.white12),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'INCIDENT PHOTO',
          style: TextStyle(
            color: yellow,
            fontWeight: FontWeight.bold,
            fontSize: 13,
          ),
        ),
        const SizedBox(height: 12),
        ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: Image.file(
            File(widget.photoPath!),
            width: double.infinity,
            height: 180,
            fit: BoxFit.contain,
          ),
        ),
      ],
    ),
  ),
  const SizedBox(height: 18),
],
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: card,
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: Colors.white12),
                  ),
                  child: Column(
                    children: [
                      Text(
                        _loading ? 'GETTING LOCATION & SAVING EVENT' : 'ALERT COUNTDOWN',
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          color: yellow,
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 12),
                      if (_loading)
                        const CircularProgressIndicator(color: yellow)
                      else if (_error != null)
                        Text(
                          _error!,
                          textAlign: TextAlign.center,
                          style: const TextStyle(color: Colors.orangeAccent),
                        )
                      else
                        Text(
                          '$_secondsRemaining',
                          style: const TextStyle(
                            color: red,
                            fontSize: 58,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      if (_eventId != null) ...[
                        const SizedBox(height: 8),
                        const Text(
                          'Crash event saved to backend',
                          style: TextStyle(color: green, fontSize: 12),
                        ),
                      ],
                    ],
                  ),
                ),
                const SizedBox(height: 22),
                SizedBox(
                  width: double.infinity,
                  height: 54,
                  child: ElevatedButton.icon(
                    onPressed: _loading || _updating || _eventId == null
                        ? null
                        : _iAmOkay,
                    icon: const Icon(Icons.check_circle_outline),
                    label: const Text("I'M OKAY"),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: green,
                      foregroundColor: bg,
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: OutlinedButton(
                    onPressed: _loading || _updating || _eventId == null
                        ? null
                        : _cancelAlert,
                    style: OutlinedButton.styleFrom(
                      foregroundColor: Colors.white,
                      side: const BorderSide(color: Colors.white24),
                    ),
                    child: const Text('CANCEL ALERT OPTIONS'),
                  ),
                ),
                const SizedBox(height: 10),

SizedBox(
  width: double.infinity,
  height: 50,
  child: ElevatedButton.icon(
    onPressed: _loading || _updating || _eventId == null
        ? null
        : _activateEmergency,
    icon: const Icon(Icons.sos),
    label: const Text('NO, I NEED HELP'),
    style: ElevatedButton.styleFrom(
      backgroundColor: Colors.red,
      foregroundColor: Colors.white,
    ),
  ),
),

const SizedBox(height: 10),

SizedBox(
  width: double.infinity,
  height: 50,
  child: OutlinedButton.icon(
    onPressed: _loading || _updating
        ? null
        : _startVoiceRecognition,
    icon: Icon(
      _isListening ? Icons.mic : Icons.mic_none,
    ),
    label: Text(
      _isListening
          ? 'LISTENING... SAY YES OR NO'
          : 'SPEAK YES / NO',
    ),
  ),
),

const SizedBox(height: 10),
                if (_error != null) ...[
                  const SizedBox(height: 14),
                  TextButton(
                    onPressed: _createCrashEvent,
                    child: const Text('Try location and save again'),
                  ),
                ],
                const SizedBox(height: 16),
                const Text(
                  'Demo only: marking an alert as sent does not send a real SMS or phone call.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.white38, fontSize: 11),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}