
import 'package:flutter/material.dart';

import 'login_screen.dart';

const Color riderBg = Color(0xFF05090F);
const Color riderYellow = Color(0xFFFFC629);
const Color riderRed = Color(0xFFFF4545);

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() =>
      _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final PageController _pageController = PageController();
  int _currentPage = 0;

  final List<Map<String, dynamic>> _pages = [
    {
      'title': 'Your Safety\nRides With You',
      'description':
          'Automatic crash detection,\nemergency alerts and a safety\nnetwork for every ride.',
      'icon': Icons.sports_motorsports,
      'accent': riderYellow,
      'features': [
        ['Crash Detection', 'Detect potential crash events', Icons.health_and_safety, riderRed],
        ['Emergency Alerts', 'Notify your emergency contacts', Icons.notifications_active, riderRed],
        ['Relay Network', 'SOS through a nearby gateway', Icons.cell_tower, riderYellow],
      ],
    },
    {
      'title': 'Smart Crash\nDetection',
      'description':
          'Your safety comes first. Get time\nto respond when a possible crash\nis detected.',
      'icon': Icons.health_and_safety,
      'accent': riderRed,
      'features': [
        ['Motion Monitoring', 'Monitor sudden movement', Icons.speed, riderRed],
        ['SOS Countdown', 'Allow time to confirm your safety', Icons.timer_outlined, riderYellow],
        ['Quick Emergency Alert', 'Trigger an SOS when needed', Icons.sos, riderRed],
      ],
    },
    {
      'title': 'Help Beyond\nMobile Network',
      'description':
          'A relay-based SOS system designed\nto pass emergency messages to a\ngateway when phone internet fails.',
      'icon': Icons.cell_tower,
      'accent': const Color(0xFF00D99A),
      'features': [
        ['LoRa Relay', 'Send messages between nearby nodes', Icons.router, const Color(0xFF00D99A)],
        ['Location Sharing', 'Include GPS when a valid fix exists', Icons.location_on, riderYellow],
        ['Emergency Contacts', 'Notify contacts via an online gateway', Icons.people_alt, const Color(0xFF00D99A)],
      ],
    },
  ];

 

  void _skip() {
    _pageController.animateToPage(
      _pages.length - 1,
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeInOut,
    );
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: riderBg,
      body: SafeArea(
        child: Column(
          children: [
            Align(
              alignment: Alignment.centerRight,
              child: TextButton(
                onPressed: _skip,
                child: const Text(
                  'Skip',
                  style: TextStyle(
                    color: riderYellow,
                    fontSize: 14,
                  ),
                ),
              ),
            ),

            Expanded(
              child: PageView.builder(
                controller: _pageController,
                itemCount: _pages.length,
                onPageChanged: (index) {
                  setState(() => _currentPage = index);
                },
                itemBuilder: (context, index) {
                  final page = _pages[index];
                  final accent = page['accent'] as Color;
                  final features =
                      page['features'] as List<List<dynamic>>;

                  return Padding(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 26,
                    ),
                    child: Column(
                      children: [
                        const SizedBox(height: 12),

                        Text(
                          page['title'] as String,
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            fontSize: 30,
                            height: 1.2,
                            fontWeight: FontWeight.bold,
                            letterSpacing: -0.5,
                            color: Colors.white,
                          ),
                        ),

                        const SizedBox(height: 14),

                        Text(
                          page['description'] as String,
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            color: Color(0xFFB7C0CE),
                            fontSize: 14,
                            height: 1.5,
                          ),
                        ),

                        Expanded(
                          child: Center(
                            child: Container(
                              width: 245,
                              height: 265,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                gradient: RadialGradient(
                                  colors: [
                                    accent.withValues(alpha: 0.17),
                                    const Color(0xFF101722),
                                    riderBg,
                                  ],
                                ),
                              ),
                              child: Stack(
                                alignment: Alignment.center,
                                children: [
                                  Container(
                                    width: 205,
                                    height: 205,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      border: Border.all(
                                        color: accent.withValues(
                                          alpha: 0.25,
                                        ),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    width: 155,
                                    height: 155,
                                    decoration: BoxDecoration(
                                      borderRadius:
                                          BorderRadius.circular(38),
                                      gradient: const LinearGradient(
                                        colors: [
                                          Color(0xFF293647),
                                          Color(0xFF090D13),
                                        ],
                                        begin: Alignment.topLeft,
                                        end: Alignment.bottomRight,
                                      ),
                                      border: Border.all(
                                        color: accent,
                                        width: 1.5,
                                      ),
                                      boxShadow: [
                                        BoxShadow(
                                          color: accent.withValues(
                                            alpha: 0.15,
                                          ),
                                          blurRadius: 28,
                                        ),
                                      ],
                                    ),
                                    child: Icon(
                                      page['icon'] as IconData,
                                      size: 82,
                                      color: accent,
                                    ),
                                  ),
                                  Positioned(
                                    bottom: 20,
                                    child: Container(
                                      padding:
                                          const EdgeInsets.symmetric(
                                        horizontal: 15,
                                        vertical: 7,
                                      ),
                                      decoration: BoxDecoration(
                                        color: const Color(0xFF101722),
                                        borderRadius:
                                            BorderRadius.circular(20),
                                        border: Border.all(
                                          color: accent.withValues(
                                            alpha: 0.45,
                                          ),
                                        ),
                                      ),
                                      child: Text(
                                        index == 0
                                            ? 'RIDE SMART'
                                            : index == 1
                                                ? 'SAFETY FIRST'
                                                : 'SOS NETWORK',
                                        style: TextStyle(
                                          color: accent,
                                          fontSize: 10,
                                          letterSpacing: 1.5,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),

                        const SizedBox(height: 8),

                        ...features.map((feature) {
                          return _FeatureRow(
                            title: feature[0] as String,
                            subtitle: feature[1] as String,
                            icon: feature[2] as IconData,
                            color: feature[3] as Color,
                          );
                        }),
                      ],
                    ),
                  );
                },
              ),
            ),

            const SizedBox(height: 8),

            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(
                _pages.length,
                (index) => AnimatedContainer(
                  duration: const Duration(milliseconds: 250),
                  margin: const EdgeInsets.symmetric(horizontal: 4),
                  width: _currentPage == index ? 19 : 6,
                  height: 6,
                  decoration: BoxDecoration(
                    color: _currentPage == index
                        ? riderYellow
                        : const Color(0xFF414956),
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
              ),
            ),

            const SizedBox(height: 20),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 25),
              child: SizedBox(
                width: double.infinity,
                height: 52,
                child: 
ElevatedButton(
  onPressed: () {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => const LoginScreen(),
      ),
    );
  },
  style: ElevatedButton.styleFrom(
    backgroundColor: const Color(0xFFFFC52E),
    foregroundColor: Colors.black,
    minimumSize: const Size(double.infinity, 52),
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(12),
    ),
  ),
  child: const Text(
    'Get Started',
    style: TextStyle(
      fontSize: 16,
      fontWeight: FontWeight.bold,
    ),
  ),
)


              ),
            ),

            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}

class _FeatureRow extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final Color color;

  const _FeatureRow({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 11),
      child: Row(
        children: [
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, color: color, size: 21),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  subtitle,
                  style: const TextStyle(
                    color: Color(0xFF9CA7B7),
                    fontSize: 11,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
