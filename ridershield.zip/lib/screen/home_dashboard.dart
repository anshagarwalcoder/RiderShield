import 'dart:convert';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:http/http.dart' as http;
import 'package:geolocator/geolocator.dart';
import '../rider_location_service.dart';

import 'live_ride_screen.dart';
import 'crash_detected_screen.dart';
import 'history_screen.dart';
import 'live_map_widget.dart';
import 'menu.dart';
import 'notifications_screen.dart';

const String backendUrl =
     'https://distributed-controlling-owns-waves.trycloudflare.com';
// Sends a manual SOS event to the RiderShield backend.
// The backend saves the event in Firestore.
Future<void> sendSosEvent() async {
  // Do not send fake coordinates: fetch the browser's real current location.
  final Position position = await RiderLocationService.getCurrentPosition();

  final response = await http
      .post(
        Uri.parse('$backendUrl/api/crash'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'deviceId': 'helmet-01',
          'eventType': 'manual_sos',
          'latitude': position.latitude,
          'longitude': position.longitude,
        }),
      )
      .timeout(const Duration(seconds: 15));

  if (response.statusCode != 201) {
    throw Exception('Backend returned ${response.statusCode}: ${response.body}');
  }
}

class HomeDashboard extends StatelessWidget {
  const HomeDashboard({super.key});

  static const Color backgroundColor = Color(0xFF050B12);
  static const Color cardColor = Color(0xFF0D1722);
  static const Color yellowColor = Color(0xFFFFC52E);
  static const Color greenColor = Color(0xFF00E69A);
  static const Color redColor = Color(0xFFFF302F);

 Future<void> confirmAndSendSos(
    BuildContext context,
    BuildContext dialogContext,
  ) async {
    Navigator.pop(dialogContext);

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => const CrashDetectedScreen(),
      ),
    );
  }
  // Sends a test push notification through the backend.
  Future<void> sendTestPushNotification(BuildContext context) async {
    final user = FirebaseAuth.instance.currentUser;

    if (user == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please log in before testing notifications.')),
      );
      return;
    }

    try {
      final idToken = await user.getIdToken();

      if (idToken == null || idToken.isEmpty) {
        throw Exception('Could not get Firebase ID token.');
      }

      final response = await http.post(
  Uri.parse('$backendUrl/api/push/test'),
  headers: {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer $idToken',
  },
  body: jsonEncode({
    'userId': user.uid,
  }),
      ).timeout(const Duration(seconds: 15));

      if (!context.mounted) return;

      if (response.statusCode == 200) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Test push response: ${response.body}')),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Test push failed (${response.statusCode}): ${response.body}'),
            backgroundColor: redColor,
          ),
        );
      }
    } catch (error) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Test push failed: $error'),
          backgroundColor: redColor,
        ),
      );
    }
  }

  // Creates demo SMS records for this signed-in rider's saved emergency contacts.
  // This does NOT send real SMS messages.
  Future<void> sendDemoSms(BuildContext context) async {
    final user = FirebaseAuth.instance.currentUser;

    if (user == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please log in before testing demo SMS.')),
      );
      return;
    }

    try {
      final idToken = await user.getIdToken();

      if (idToken == null || idToken.isEmpty) {
        throw Exception('Could not get Firebase ID token.');
      }

      final response = await http.post(
        Uri.parse('$backendUrl/api/sms/demo'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $idToken',
        },
      ).timeout(const Duration(seconds: 15));

      if (!context.mounted) return;

      String resultMessage;
      try {
        final decoded = jsonDecode(response.body);
        resultMessage = decoded is Map && decoded['message'] is String
            ? decoded['message'] as String
            : response.body;
      } catch (_) {
        resultMessage = response.body;
      }

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            response.statusCode == 201
                ? '$resultMessage (No real SMS sent)'
                : 'Demo SMS failed (${response.statusCode}): $resultMessage',
          ),
          backgroundColor:
              response.statusCode == 201 ? greenColor : redColor,
          duration: const Duration(seconds: 5),
        ),
      );
    } catch (error) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Demo SMS request failed: $error'),
          backgroundColor: redColor,
        ),
      );
    }
  }

  void showSosConfirmation(BuildContext context) {
    showDialog(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          backgroundColor: cardColor,
          title: const Text(
            'Emergency SOS',
            style: TextStyle(color: Colors.white),
          ),
          content: const Text(
            'Do you need emergency assistance?',
            style: TextStyle(color: Colors.white70),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: redColor,
                foregroundColor: Colors.white,
              ),
              onPressed: () {
                confirmAndSendSos(context, dialogContext);
              },
              child: const Text('Confirm'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundColor,

      // Top App Bar
      appBar: AppBar(
        backgroundColor: backgroundColor,
        elevation: 0,
        automaticallyImplyLeading: false,
        title: Row(
          children: [
            const Icon(
              Icons.shield_rounded,
              color: yellowColor,
              size: 27,
            ),
            const SizedBox(width: 8),
            const Text(
              'RIDER',
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 19,
              ),
            ),
            const Text(
              'SHIELD',
              style: TextStyle(
                color: yellowColor,
                fontWeight: FontWeight.bold,
                fontSize: 19,
              ),
            ),
          ],
        ),
        actions: [
  IconButton(
    onPressed: () {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) =>  NotificationsScreen(),
        ),
      );
    },
    icon: const Icon(
      Icons.notifications_none_rounded,
      color: Colors.white,
    ),
  ),
],
      ),

      // Dashboard Content
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // 1. System Active Card
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [
                      Color(0xFF003D2C),
                      Color(0xFF0D201F),
                    ],
                  ),
                  borderRadius: BorderRadius.circular(15),
                  border: Border.all(
                    color: greenColor.withValues(alpha: 0.5),
                  ),
                ),
                child: Row(
                  children: [
                    const Icon(
                      Icons.verified_user_rounded,
                      color: greenColor,
                      size: 42,
                    ),
                    const SizedBox(width: 12),
                    const Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'SYSTEM ACTIVE',
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 15,
                            ),
                          ),
                          SizedBox(height: 5),
                          Text(
                            'Riding Safely',
                            style: TextStyle(
                              color: greenColor,
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const Icon(
                      Icons.motorcycle_rounded,
                      color: yellowColor,
                      size: 43,
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 14),

              // 2. Helmet and Battery Status
              Row(
                children: [
                  Expanded(
                    child: statusCard(
                      icon: Icons.sports_motorsports_rounded,
                      title: 'Helmet',
                      subtitle: 'Connected',
                      color: greenColor,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: statusCard(
                      icon: Icons.battery_charging_full_rounded,
                      title: 'Battery',
                      subtitle: '87%',
                      color: greenColor,
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 10),

              // 3. Network and GPS Status
              Row(
                children: [
                  Expanded(
                    child: statusCard(
                      icon: Icons.signal_cellular_alt_rounded,
                      title: 'Network',
                      subtitle: 'Online (4G)',
                      color: greenColor,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: statusCard(
                      icon: Icons.gps_fixed_rounded,
                      title: 'GPS',
                      subtitle: 'Locked',
                      color: greenColor,
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 16),

              // 4. Real map with device/browser GPS location
              const LiveMapWidget(),
              const SizedBox(height: 14),
              const RecentHardwareAlerts(),

              const SizedBox(height: 14),

              // 5. Ride Statistics (demo values)
              Row(
                children: [
                  Expanded(
                    child: statCard(
                      title: 'Ride Time',
                      value: '01:24:36',
                      icon: Icons.timer_outlined,
                    ),
                  ),
                  const SizedBox(width: 9),
                  Expanded(
                    child: statCard(
                      title: 'Speed',
                      value: '42 km/h',
                      icon: Icons.speed_rounded,
                    ),
                  ),
                  const SizedBox(width: 9),
                  Expanded(
                    child: statCard(
                      title: 'Distance',
                      value: '28.4 km',
                      icon: Icons.route_rounded,
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 18),

              // 6. SOS Emergency Button - connected to backend
              SizedBox(
                width: double.infinity,
                height: 52,
                child: ElevatedButton.icon(
                  onPressed: () => showSosConfirmation(context),
                  icon: const Icon(
                    Icons.phone_rounded,
                    color: Colors.white,
                  ),
                  label: const Text(
                    'SOS EMERGENCY',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: redColor,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 12),

              // Test push notification button
              SizedBox(
                width: double.infinity,
                height: 48,
                child: OutlinedButton.icon(
                  onPressed: () => sendTestPushNotification(context),
                  icon: const Icon(Icons.notifications_active_rounded),
                  label: const Text('SEND TEST PUSH NOTIFICATION'),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: yellowColor,
                    side: const BorderSide(color: yellowColor),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 12),

              // Demo SMS button (records only; sends no real SMS)
              SizedBox(
                width: double.infinity,
                height: 48,
                child: OutlinedButton.icon(
                  onPressed: () => sendDemoSms(context),
                  icon: const Icon(Icons.sms_outlined),
                  label: const Text('TEST DEMO SMS (NO SMS SENT)'),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: greenColor,
                    side: const BorderSide(color: greenColor),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 22),

              // Footer Information
              const Center(
                child: Text(
                  'Ride Safe • Stay Protected',
                  style: TextStyle(
                    color: Colors.white54,
                    fontSize: 12,
                  ),
                ),
              ),

              const SizedBox(height: 12),
            ],
          ),
        ),
      ),

      // 7. Bottom Navigation Bar
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: const Color(0xFF08111B),
        selectedItemColor: yellowColor,
        unselectedItemColor: Colors.white54,
        currentIndex: 0,
        type: BottomNavigationBarType.fixed,
        showUnselectedLabels: true,
        selectedFontSize: 11,
        unselectedFontSize: 11,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home_rounded),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.motorcycle_rounded),
            label: 'Ride',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.history_rounded),
            label: 'History',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person_outline_rounded),
            label: 'Profile',
          ),
        ],
        onTap: (index) {
  if (index == 2) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => const HistoryScreen(),
      ),
    );
  } else if (index == 1) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => const LiveRideScreen(),
      ),
    );
  } else if (index == 3) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => const ProfileScreen(),
      ),
    );
  }
},
      ),
    );
  }

  // Reusable Status Card
  Widget statusCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required Color color,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 10,
        vertical: 15,
      ),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white10),
      ),
      child: Row(
        children: [
          Icon(icon, color: color, size: 25),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  subtitle,
                  style: const TextStyle(
                    color: Colors.white70,
                    fontSize: 10,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // Reusable Statistics Card
  Widget statCard({
    required String title,
    required String value,
    required IconData icon,
  }) {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white10),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(
            icon,
            color: yellowColor,
            size: 19,
          ),
          const SizedBox(height: 8),
          Text(
            title,
            style: const TextStyle(
              color: Colors.white60,
              fontSize: 10,
            ),
          ),
          const SizedBox(height: 5),
          FittedBox(
            fit: BoxFit.scaleDown,
            alignment: Alignment.centerLeft,
            child: Text(
              value,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 14,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
class RecentHardwareAlerts extends StatefulWidget {
  const RecentHardwareAlerts({super.key});

  @override
  State<RecentHardwareAlerts> createState() =>
      _RecentHardwareAlertsState();
}

class _RecentHardwareAlertsState extends State<RecentHardwareAlerts> {
  List<Map<String, dynamic>> events = [];
  bool loading = true;
  String? error;
  Timer? refreshTimer;

  String? lastSeenEventId;
  bool initialFetchDone = false;
  bool openingCrashScreen = false;

  @override
  void initState() {
    super.initState();
    loadEvents();

    refreshTimer = Timer.periodic(
      const Duration(seconds: 3),
      (_) => loadEvents(),
    );
  }

  Future<void> loadEvents() async {
    try {
      final response = await http
          .get(Uri.parse('$backendUrl/api/crash'))
          .timeout(const Duration(seconds: 10));

      if (response.statusCode != 200) {
        throw Exception('Server returned ${response.statusCode}');
      }

      final decoded = jsonDecode(response.body);
      if (decoded is! Map || decoded['events'] is! List) {
        throw Exception('Unexpected backend response');
      }

      final allEvents = (decoded['events'] as List)
          .whereType<Map>()
          .map((e) => Map<String, dynamic>.from(e))
          .toList();

      final hardwareEvents = allEvents
          .where((e) => e['source'] == 'hardware')
          .toList();

      if (!mounted) return;

      // First fetch: remember the latest event without opening
      // a screen for an old event from Firestore.
      if (!initialFetchDone) {
        initialFetchDone = true;

        if (hardwareEvents.isNotEmpty) {
          lastSeenEventId =
              hardwareEvents.first['eventId']?.toString();
        }
      } else {
        // Backend returns newest events first.
        final newest = hardwareEvents.isEmpty
            ? null
            : hardwareEvents.first;

        final newestId = newest?['eventId']?.toString();

        if (newest != null &&
            newestId != null &&
            newestId != lastSeenEventId) {
          lastSeenEventId = newestId;

          final isCrashOrSos =
              newest['eventType'] == 'manual_sos' ||
              newest['eventType'] == 'possible_crash';

          if (isCrashOrSos && !openingCrashScreen) {
            openingCrashScreen = true;

            WidgetsBinding.instance.addPostFrameCallback((_) {
              if (!mounted) {
                openingCrashScreen = false;
                return;
              }

              Navigator.of(context)
                  .push(
                    MaterialPageRoute(
                      builder: (_) => const CrashDetectedScreen(),
                    ),
                  )
                  .then((_) {
                    openingCrashScreen = false;
                  });
            });
          }
        }
      }

      setState(() {
        events = hardwareEvents;
        error = null;
        loading = false;
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        error = e.toString();
        loading = false;
      });
    }
  }

  @override
  void dispose() {
    refreshTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF0D1722),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white10),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(
                Icons.sensors_rounded,
                color: Color(0xFFFFC52E),
              ),
              const SizedBox(width: 8),
              const Expanded(
                child: Text(
                  'HARDWARE CRASH ALERTS',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              IconButton(
                onPressed: loadEvents,
                icon: const Icon(
                  Icons.refresh,
                  color: Color(0xFFFFC52E),
                ),
              ),
            ],
          ),
          if (loading)
            const Center(child: CircularProgressIndicator())
          else if (error != null)
            Text(
              'Could not load events: $error',
              style: const TextStyle(color: Colors.redAccent),
            )
          else if (events.isEmpty)
            const Text(
              'No hardware crash events yet.',
              style: TextStyle(color: Colors.white70),
            )
          else
            ...events.take(10).map((event) {
              final isSos = event['eventType'] == 'manual_sos';

              return ListTile(
                contentPadding: EdgeInsets.zero,
                leading: Icon(
                  isSos
                      ? Icons.sos_rounded
                      : Icons.warning_amber_rounded,
                  color: Colors.redAccent,
                ),
                title: Text(
                  isSos ? 'Emergency SOS' : 'Possible Crash',
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                subtitle: Text(
                  'Device: ${event['deviceId'] ?? 'Unknown'}\n'
                  'Status: ${event['status'] ?? 'pending'}',
                  style: const TextStyle(color: Colors.white70),
                ),
              );
            }),
        ],
      ),
    );
  }
}