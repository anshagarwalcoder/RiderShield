
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({super.key});

  @override
  State<NotificationsScreen> createState() =>
      _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  static const Color background = Color(0xFF050B12);
  static const Color card = Color(0xFF0D1722);
  static const Color gold = Color(0xFFFFC52E);
  static const Color muted = Color(0xFF9BA8B7);
  static const Color green = Color(0xFF00E69A);
  static const Color blue = Color(0xFF65A9FF);
  static const Color red = Color(0xFFFF5252);

  static const String apiUrl =
      'http://100.112.232.64:3000/api/crash';

  static const String readKey = 'ridershield_read_notifications';
  static const String hiddenKey = 'ridershield_hidden_notifications';

  final List<Map<String, dynamic>> notifications = [];

  Set<String> readIds = {};
  Set<String> hiddenIds = {};

  bool isLoading = false;
  String? errorMessage;

  @override
  void initState() {
    super.initState();
    initializeNotifications();
  }

  Future<void> initializeNotifications() async {
    final prefs = await SharedPreferences.getInstance();

    readIds = (prefs.getStringList(readKey) ?? []).toSet();
    hiddenIds = (prefs.getStringList(hiddenKey) ?? []).toSet();

    final samples = [
      {
        'id': 'sample_ready',
        'title': 'RiderShield is Ready',
        'message': 'Your safety dashboard is ready to use.',
        'time': 'Just now',
        'icon': Icons.shield_rounded,
        'color': green,
        'source': 'local',
      },
      {
        'id': 'sample_helmet',
        'title': 'Helmet Status',
        'message':
            'Check your helmet connection before starting a ride.',
        'time': 'Today',
        'icon': Icons.sports_motorsports_rounded,
        'color': gold,
        'source': 'local',
      },
      {
        'id': 'sample_safety',
        'title': 'Safety Reminder',
        'message': 'Wear your helmet and ride safely.',
        'time': 'Today',
        'icon': Icons.security_rounded,
        'color': blue,
        'source': 'local',
      },
    ];

    if (!mounted) return;

    setState(() {
      notifications
        ..clear()
        ..addAll(
          samples
              .where((item) => !hiddenIds.contains(item['id']))
              .map((item) => {
                    ...item,
                    'read': readIds.contains(item['id']),
                  }),
        );
    });

    await loadNotifications();
  }

  Future<void> saveNotificationState() async {
    final prefs = await SharedPreferences.getInstance();

    await prefs.setStringList(readKey, readIds.toList());
    await prefs.setStringList(hiddenKey, hiddenIds.toList());
  }

  Future<void> loadNotifications() async {
    if (isLoading) return;

    setState(() {
      isLoading = true;
      errorMessage = null;
    });

    try {
      final response = await http
          .get(Uri.parse(apiUrl))
          .timeout(const Duration(seconds: 15));

      if (response.statusCode != 200) {
        throw Exception('Server error: ${response.statusCode}');
      }

      final data = jsonDecode(response.body);

      if (data is! Map || data['events'] is! List) {
        throw Exception('Invalid server response');
      }

      final backendItems = <Map<String, dynamic>>[];

      for (final event in data['events'] as List) {
        if (event is! Map) continue;

        final eventType = event['eventType']?.toString();
        final isSos = eventType == 'manual_sos';

        final rawTime = event['receivedAt']?.toString() ?? '';
        final parsedTime = DateTime.tryParse(rawTime);

        final formattedTime = parsedTime == null
            ? (rawTime.isEmpty ? 'Time unavailable' : rawTime)
            : _formatTime(parsedTime.toLocal());

        final latitude = event['latitude'];
        final longitude = event['longitude'];
        final status = event['status']?.toString() ?? 'pending';

        final eventId = event['eventId']?.toString() ??
            event['id']?.toString() ??
            '${eventType}_${rawTime}_${latitude}_$longitude';

        final id = 'backend_$eventId';

        // Don't show events the user has already cleared.
        if (hiddenIds.contains(id)) continue;

        final locationText =
            latitude != null && longitude != null
                ? '\nLocation: $latitude, $longitude'
                : '';

        backendItems.add({
          'id': id,
          'title': isSos ? 'Emergency SOS' : 'Crash Alert',
          'message':
              '${isSos ? 'Emergency SOS received.' : 'Possible crash detected.'}'
              '\nStatus: $status'
              '$locationText',
          'time': formattedTime,
          'icon': isSos
              ? Icons.emergency_rounded
              : Icons.warning_amber_rounded,
          'color': isSos ? red : gold,
          'source': 'backend',
          'read': readIds.contains(id),
        });
      }

      if (!mounted) return;

      setState(() {
        notifications.removeWhere(
          (item) => item['source'] == 'backend',
        );

        notifications.addAll(backendItems);
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        errorMessage =
            'Could not load server notifications. Check your '
            'connection and backend server.';
      });
    } finally {
      if (mounted) {
        setState(() {
          isLoading = false;
        });
      }
    }
  }

  String _formatTime(DateTime time) {
    return '${time.day.toString().padLeft(2, '0')}/'
        '${time.month.toString().padLeft(2, '0')}/'
        '${time.year} '
        '${time.hour.toString().padLeft(2, '0')}:'
        '${time.minute.toString().padLeft(2, '0')}';
  }

  Future<void> markAllAsRead() async {
    setState(() {
      for (final item in notifications) {
        item['read'] = true;
        readIds.add(item['id'] as String);
      }
    });

    await saveNotificationState();

    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('All notifications marked as read'),
      ),
    );
  }

  Future<void> clearNotifications() async {
    setState(() {
      for (final item in notifications) {
        hiddenIds.add(item['id'] as String);
      }

      notifications.clear();
    });

    await saveNotificationState();

    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Notifications cleared'),
      ),
    );
  }

  Future<void> markAsRead(Map<String, dynamic> item) async {
    final id = item['id'] as String;

    setState(() {
      item['read'] = true;
      readIds.add(id);
    });

    await saveNotificationState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: background,
      appBar: AppBar(
        backgroundColor: background,
        foregroundColor: Colors.white,
        elevation: 0,
        title: const Text(
          'Notifications',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: [
          IconButton(
            tooltip: 'Refresh notifications',
            onPressed: isLoading ? null : loadNotifications,
            icon: const Icon(
              Icons.refresh_rounded,
              color: Colors.white,
            ),
          ),
          PopupMenuButton<String>(
            icon: const Icon(
              Icons.more_vert,
              color: Colors.white,
            ),
            color: card,
            onSelected: (value) {
              if (value == 'read') {
                markAllAsRead();
              } else if (value == 'clear') {
                clearNotifications();
              }
            },
            itemBuilder: (context) => const [
              PopupMenuItem(
                value: 'read',
                child: Text(
                  'Mark all as read',
                  style: TextStyle(color: Colors.white),
                ),
              ),
              PopupMenuItem(
                value: 'clear',
                child: Text(
                  'Clear all notifications',
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ],
          ),
        ],
      ),
      body: Column(
        children: [
          if (isLoading)
            const LinearProgressIndicator(
              color: gold,
              backgroundColor: card,
            ),
          if (errorMessage != null)
            Container(
              width: double.infinity,
              margin: const EdgeInsets.fromLTRB(16, 12, 16, 0),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: card,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                children: [
                  const Icon(
                    Icons.wifi_off_rounded,
                    color: gold,
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      errorMessage!,
                      style: const TextStyle(color: muted),
                    ),
                  ),
                  TextButton(
                    onPressed: isLoading ? null : loadNotifications,
                    child: const Text(
                      'Retry',
                      style: TextStyle(color: gold),
                    ),
                  ),
                ],
              ),
            ),
          Expanded(
            child: notifications.isEmpty
                ? Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(
                          Icons.notifications_off_outlined,
                          size: 65,
                          color: muted,
                        ),
                        const SizedBox(height: 16),
                        const Text(
                          'No notifications',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 8),
                        const Text(
                          'You are all caught up!',
                          style: TextStyle(color: muted),
                        ),
                        const SizedBox(height: 16),
                        TextButton.icon(
                          onPressed: loadNotifications,
                          icon: const Icon(
                            Icons.refresh,
                            color: gold,
                          ),
                          label: const Text(
                            'Refresh',
                            style: TextStyle(color: gold),
                          ),
                        ),
                      ],
                    ),
                  )
                : RefreshIndicator(
                    color: gold,
                    backgroundColor: card,
                    onRefresh: loadNotifications,
                    child: ListView.builder(
                      physics: const AlwaysScrollableScrollPhysics(),
                      padding: const EdgeInsets.all(16),
                      itemCount: notifications.length,
                      itemBuilder: (context, index) {
                        final item = notifications[index];
                        final itemColor = item['color'] as Color;
                        final isRead = item['read'] == true;

                        return Card(
                          color: card,
                          margin: const EdgeInsets.only(bottom: 12),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14),
                            side: BorderSide(
                              color: isRead
                                  ? Colors.white10
                                  : gold.withValues(alpha: 0.45),
                            ),
                          ),
                          child: ListTile(
                            contentPadding: const EdgeInsets.all(14),
                            leading: CircleAvatar(
                              backgroundColor:
                                  itemColor.withValues(alpha: 0.12),
                              child: Icon(
                                item['icon'] as IconData,
                                color: itemColor,
                              ),
                            ),
                            title: Text(
                              item['title'] as String,
                              style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            subtitle: Padding(
                              padding: const EdgeInsets.only(top: 6),
                              child: Column(
                                crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    item['message'] as String,
                                    style: const TextStyle(
                                      color: muted,
                                      fontSize: 13,
                                    ),
                                  ),
                                  const SizedBox(height: 8),
                                  Text(
                                    item['time'] as String,
                                    style: const TextStyle(
                                      color: gold,
                                      fontSize: 11,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            trailing: !isRead
                                ? const Icon(
                                    Icons.circle,
                                    color: gold,
                                    size: 9,
                                  )
                                : null,
                            onTap: () => markAsRead(item),
                          ),
                        );
                      },
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}
