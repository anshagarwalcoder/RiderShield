import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  // Backend laptop ka Wi-Fi IP
  static const String baseUrl = 'http://10.155.113.102:3000';

  static Future<List<dynamic>> getCrashEvents() async {
    final uri = Uri.parse('$baseUrl/api/crash');

    final response = await http
        .get(uri)
        .timeout(const Duration(seconds: 10));

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);

      if (data['success'] == true && data['events'] is List) {
        return data['events'] as List<dynamic>;
      }

      throw Exception('Unexpected response from RiderShield backend');
    }

    throw Exception(
      'Backend returned HTTP ${response.statusCode}',
    );
  }
}