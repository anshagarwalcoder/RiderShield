import 'package:geolocator/geolocator.dart';

/// Fetches the current browser/device location.
/// On Flutter Web, run on localhost or HTTPS and allow location permission.
class RiderLocationService {
  static Future<Position> getCurrentPosition() async {
    final serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      throw Exception('Location services are turned off. Enable location and try again.');
    }

    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }

    if (permission == LocationPermission.denied) {
      throw Exception('Location permission was denied. Allow location in Chrome site settings.');
    }
    if (permission == LocationPermission.deniedForever) {
      throw Exception('Location permission is blocked. Open Chrome site settings and allow Location.');
    }

    return Geolocator.getCurrentPosition(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.high,
        timeLimit: Duration(seconds: 20),
      ),
    );
  }
}
