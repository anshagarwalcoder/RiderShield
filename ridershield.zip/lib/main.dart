import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:device_preview/device_preview.dart';
import 'firebase_options.dart';
import 'screen/splash_screen.dart';
import 'screen/login_screen.dart';
import 'screen/home_dashboard.dart';



// Keep this URL consistent with the backend address.
const String backendUrl = 'http://100.112.232.64:3000';

const String vapidKey =
    'BI5ceZJUTShmqhLWhw4eW--SEp68axrS5566_8F9KJ_ljicbRFEw7ZcH_R5FIBe50jW66krMo913_HkY4LttBMc';

    final GlobalKey<NavigatorState> navigatorKey =
    GlobalKey<NavigatorState>();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  runApp(
    DevicePreview(
      enabled: true,
      builder: (context) => const RiderShieldApp(),
    ),
  );

  // Start notifications without blocking the UI.
  initializePushNotifications();
}

Future<void> initializePushNotifications() async {
  try {
    final messaging = FirebaseMessaging.instance;

    final settings = await messaging.requestPermission(
      alert: true,
      badge: true,
      sound: true,
    );

    debugPrint(
      'Notification permission: ${settings.authorizationStatus}',
    );

    final token = await messaging.getToken(
      vapidKey: vapidKey,
    );

    if (token != null && token.isNotEmpty) {
      debugPrint('FCM token generated successfully.');

      if (FirebaseAuth.instance.currentUser != null) {
        await registerPushToken(token);
      }
    }

    debugPrint(
      'Current Firebase user: '
      '${FirebaseAuth.instance.currentUser?.uid}',
    );

    // Register when the user logs in.
    FirebaseAuth.instance.authStateChanges().listen((user) async {
      debugPrint('Auth state changed. User: ${user?.uid ?? "null"}');

      if (user != null && token != null && token.isNotEmpty) {
        await registerPushToken(token);
      }
    });

    // Handle messages received while the app is in the foreground.
    FirebaseMessaging.onMessage.listen((message) {
  debugPrint('FCM message received: ${message.messageId}');
  debugPrint('FCM title: ${message.notification?.title}');
  debugPrint('FCM body: ${message.notification?.body}');

  if (message.notification != null) {
    ScaffoldMessenger.maybeOf(
      navigatorKey.currentContext!,
    )?.showSnackBar(
      SnackBar(
        content: Text(
          '${message.notification!.title ?? "RiderShield"}: '
          '${message.notification!.body ?? "New alert received"}',
        ),
        duration: const Duration(seconds: 8),
      ),
    );
  }
});

    FirebaseMessaging.onMessageOpenedApp.listen((message) {
      debugPrint('Notification opened: ${message.data}');
    });
  } catch (e, stackTrace) {
    debugPrint('FCM setup error: $e');
    debugPrintStack(stackTrace: stackTrace);
  }
}

/// Register the token once a Firebase user is signed in.
Future<void> registerPushToken(String token) async {
  final user = FirebaseAuth.instance.currentUser;

  if (user == null) {
    debugPrint('Push registration skipped: user is not signed in.');
    return;
  }

  try {
    final idToken = await user.getIdToken();

    if (idToken == null || idToken.isEmpty) {
      debugPrint('Could not get Firebase ID token.');
      return;
    }

    final response = await http.post(
      Uri.parse('$backendUrl/api/push/register'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $idToken',
      },
      body: jsonEncode({
        'token': token,
      }),
    );

    debugPrint('Push registration status: ${response.statusCode}');
    debugPrint('Push registration response: ${response.body}');
  } catch (e) {
    debugPrint('Push registration failed: $e');
  }
}

/// Send a test push notification through the backend.
Future<void> sendTestPushNotification() async {
  final user = FirebaseAuth.instance.currentUser;

  if (user == null) {
    debugPrint('Test push failed: user is not signed in.');
    return;
  }

  try {
    final idToken = await user.getIdToken();

    if (idToken == null || idToken.isEmpty) {
      debugPrint('Test push failed: Firebase ID token is missing.');
      return;
    }

    final response = await http.post(
      Uri.parse('$backendUrl/api/push/test'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $idToken',
      },
    );

    debugPrint('Test push status: ${response.statusCode}');
    debugPrint('Test push response: ${response.body}');
  } catch (e) {
    debugPrint('Test push request failed: $e');
  }
}

/// Create demo SMS records for the signed-in rider's saved emergency contacts.
/// This endpoint does NOT send real SMS.
Future<void> sendDemoSmsRequest() async {
  final user = FirebaseAuth.instance.currentUser;

  if (user == null) {
    debugPrint('Demo SMS failed: user is not signed in.');
    return;
  }

  try {
    final idToken = await user.getIdToken();

    if (idToken == null || idToken.isEmpty) {
      debugPrint('Demo SMS failed: Firebase ID token is missing.');
      return;
    }

    final response = await http.post(
      Uri.parse('$backendUrl/api/sms/demo'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $idToken',
      },
    );

    debugPrint('Demo SMS status: ${response.statusCode}');
    debugPrint('Demo SMS response: ${response.body}');
  } catch (e) {
    debugPrint('Demo SMS request failed: $e');
  }
}

/// Retry registration when Firebase Authentication changes.
Future<void> registerPushTokenWhenSignedIn(String token) async {
  final currentUser = FirebaseAuth.instance.currentUser;

  if (currentUser != null) {
    await registerPushToken(token);
    return;
  }

  debugPrint(
    'Waiting for sign-in before registering push notifications.',
  );

  final user = await FirebaseAuth.instance
      .authStateChanges()
      .firstWhere((user) => user != null);

  if (user != null) {
    await registerPushToken(token);
  }
}

class RiderShieldApp extends StatelessWidget {
  const RiderShieldApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'RiderShield',
      navigatorKey: navigatorKey,
      debugShowCheckedModeBanner: false,
      locale: DevicePreview.locale(context),
      builder: DevicePreview.appBuilder,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.red,
        ),
        useMaterial3: true,
      ),
      home: const SplashScreen(),
    );
  }
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            backgroundColor: Color(0xFF05090E),
            body: Center(
              child: CircularProgressIndicator(
                color: Color(0xFFFFC52E),
              ),
            ),
          );
        }

        if (snapshot.hasData) {
          return const HomeDashboard();
        }

        return const LoginScreen();
      },
    );
  }
}

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  String message = 'Ready to connect';
  bool loading = false;
  bool pushLoading = false;
  bool smsLoading = false;

  Future<void> sendTestCrash() async {
    setState(() {
      loading = true;
      message = 'Sending test event...';
    });

    try {
      final response = await http.post(
        Uri.parse('$backendUrl/api/crash'),
        headers: {
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'deviceId': 'helmet-01',
          'eventType': 'possible_crash',
          'latitude': 28.58,
          'longitude': 78.57,
          'source': 'simulation',
        }),
      );

      final data = jsonDecode(response.body);

      if (!mounted) return;

      setState(() {
        message = response.statusCode == 201
            ? 'SUCCESS! Event saved to Firebase.\n'
                'ID: ${data['eventId']}'
            : 'Error ${response.statusCode}: ${response.body}';
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        message = 'Connection failed: $e';
      });
    } finally {
      if (mounted) {
        setState(() {
          loading = false;
        });
      }
    }
  }

  Future<void> testPush() async {
    setState(() {
      pushLoading = true;
    });

    await sendTestPushNotification();

    if (!mounted) return;

    setState(() {
      pushLoading = false;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text(
          'Test push request sent. Check the Flutter terminal logs.',
        ),
      ),
    );
  }

  Future<void> testDemoSms() async {
    setState(() {
      smsLoading = true;
    });

    await sendDemoSmsRequest();

    if (!mounted) return;

    setState(() {
      smsLoading = false;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text(
          'Demo SMS request finished. Check the Flutter terminal logs; no real SMS was sent.',
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('RiderShield'),
        backgroundColor: Colors.red,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            tooltip: 'Logout',
            icon: const Icon(Icons.logout),
            onPressed: () async {
              await FirebaseAuth.instance.signOut();
            },
          ),
        ],
      ),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(
                Icons.health_and_safety,
                size: 90,
                color: Colors.red,
              ),
              const SizedBox(height: 16),
              const Text(
                'Smart Rider Emergency System',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 24),
              const Text('Backend: 100.112.232.64:3000'),
              const SizedBox(height: 24),
              ElevatedButton.icon(
                onPressed: loading ? null : sendTestCrash,
                icon: const Icon(Icons.warning_amber),
                label: Text(
                  loading ? 'Sending...' : 'Send Test Crash Alert',
                ),
              ),
              const SizedBox(height: 12),
              ElevatedButton.icon(
                onPressed: pushLoading ? null : testPush,
                icon: const Icon(Icons.notifications_active),
                label: Text(
                  pushLoading
                      ? 'Sending notification...'
                      : 'Send Test Push Notification',
                ),
              ),
              const SizedBox(height: 12),
              ElevatedButton.icon(
                onPressed: smsLoading ? null : testDemoSms,
                icon: const Icon(Icons.sms_outlined),
                label: Text(
                  smsLoading ? 'Preparing demo SMS...' : 'Test Demo SMS (No SMS Sent)',
                ),
              ),
              const SizedBox(height: 24),
              SelectableText(
                message,
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }
}