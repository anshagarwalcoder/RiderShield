importScripts(
  "https://www.gstatic.com/firebasejs/10.13.2/firebase-app-compat.js"
);
importScripts(
  "https://www.gstatic.com/firebasejs/10.13.2/firebase-messaging-compat.js"
);

firebase.initializeApp({
  apiKey: "AIzaSyCcTYGeU3q0W8qApdcZOC4UId3GFen8AOs",
  authDomain: "ridershield-31cb0.firebaseapp.com",
  projectId: "ridershield-31cb0",
  storageBucket: "ridershield-31cb0.firebasestorage.app",
  messagingSenderId: "104635382983",
  appId: "1:104635382983:web:b8b5099d9e8b319aae92e2",
  measurementId: "G-525S5M4E38"
});

const messaging = firebase.messaging();

messaging.onBackgroundMessage((payload) => {
  // Firebase automatically displays notification payloads.
  // Show a notification manually only for data-only messages.
  if (!payload.notification) {
    const title = payload.data?.title || "RiderShield Crash Alert";
    const options = {
      body: payload.data?.body || "Crash event received. Open RiderShield to check.",
      icon: "/icons/Icon-192.png",
      data: { url: payload.data?.url || "/" }
    };

    self.registration.showNotification(title, options);
  }
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();

  const targetUrl = new URL(
    event.notification.data?.url || "/",
    self.location.origin
  ).href;

  event.waitUntil((async () => {
    const windows = await clients.matchAll({
      type: "window",
      includeUncontrolled: true
    });

    for (const client of windows) {
      if (client.url.startsWith(self.location.origin) && "focus" in client) {
        await client.focus();
        if ("navigate" in client) await client.navigate(targetUrl);
        return;
      }
    }

    await clients.openWindow(targetUrl);
  })());
});