require("dotenv").config();
const cors = require("cors");
const express = require("express");
const path = require("path");
const crypto = require("crypto");

const { initializeApp, cert } = require("firebase-admin/app");
const { getAuth } = require("firebase-admin/auth");
const { getMessaging } = require("firebase-admin/messaging");
const {
  getFirestore,
  FieldValue,
} = require("firebase-admin/firestore");

// Firebase Admin setup
initializeApp({
  credential: cert(
    require(path.join(__dirname, "serviceAccountKey.json"))
  ),
});


const RIDERSHIELD_API_KEY = process.env.RIDERSHIELD_API_KEY;

function authenticateDevice(req, res, next) {
  const providedKey = req.get("x-api-key");

  if (
    !RIDERSHIELD_API_KEY ||
    !providedKey ||
    providedKey.length !== RIDERSHIELD_API_KEY.length ||
    !crypto.timingSafeEqual(
      Buffer.from(providedKey),
      Buffer.from(RIDERSHIELD_API_KEY)
    )
  ) {
    return res.status(401).json({
      success: false,
      message: "Unauthorized device",
    });
  }

  next();
}
const db = getFirestore();
const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json({ limit: "10kb" }));
// Log every incoming API request
app.use((req, res, next) => {
  const startedAt = Date.now();

  console.log(
    `[${new Date().toISOString()}] ${req.method} ${req.originalUrl}`
  );

  res.on("finish", () => {
    console.log(
      `[${new Date().toISOString()}] ${req.method} ${req.originalUrl} -> ${res.statusCode} (${Date.now() - startedAt}ms)`
    );
  });

  next();
});

const allowedEventTypes = ["possible_crash", "manual_sos"];
const allowedStatuses = [
  "cancelled",
  "alert_sent",
  "resolved",
  "false_alarm",
];

const validCoordinate = (value, min, max) =>
  value === undefined ||
  value === null ||
  (typeof value === "number" &&
    Number.isFinite(value) &&
    value >= min &&
    value <= max);

// Verify Firebase ID token from Authorization: Bearer <token>
async function authenticateUser(req, res, next) {
  const authHeader = req.headers.authorization || "";
  const match = authHeader.match(/^Bearer\s+(.+)$/i);

  if (!match) {
    return res.status(401).json({
      success: false,
      message: "Missing Firebase ID token",
    });
  }

  try {
    const decodedToken = await getAuth().verifyIdToken(match[1]);
    req.user = decodedToken;
    next();
  } catch (error) {
    console.error("Authentication failed:", error.message);

    return res.status(401).json({
      success: false,
      message: "Invalid or expired Firebase ID token",
    });
  }
}

const allowedActivityTypes = [
  "login",
  "logout",
  "sos",
  "crash_detected",
  "notification",
  "screen_opened",
  "button_tapped"
];
app.post("/api/activity", async (req, res) => {
  try {
    const { userId, activityType, details } = req.body ?? {};

    if (
      typeof userId !== "string" ||
      !userId.trim() ||
      !allowedActivityTypes.includes(activityType)
    ) {
      return res.status(400).json({
        success: false,
        message: "Valid userId and activityType are required"
      });
    }

    const activity = {
      userId: userId.trim(),
      activityType,
      details:
        typeof details === "string" ? details.slice(0, 500) : "",
      receivedAt: new Date().toISOString()
    };

    const doc = await db.collection("activity_logs").add(activity);

    console.log(
      `[ACTIVITY] ${activity.activityType} | User: ${activity.userId} | ID: ${doc.id}`
    );

    return res.status(201).json({
      success: true,
      message: "Activity saved",
      activityId: doc.id
    });
  } catch (error) {
    console.error("Activity logging failed:", error.message);

    return res.status(500).json({
      success: false,
      message: "Could not save activity"
    });
  }
});

// Health check
app.get("/", (req, res) => {
  res.json({
    project: "RiderShield",
    status: "Backend is running",
  });
});

// Get recent crash events
app.get("/api/crash", async (req, res) => {
  try {
    const snapshot = await db
      .collection("crash_events")
      .orderBy("receivedAt", "desc")
      .limit(50)
      .get();

    const events = snapshot.docs.map((doc) => ({
      eventId: doc.id,
      ...doc.data(),
    }));

    return res.json({
      success: true,
      count: events.length,
      events,
    });
  } catch (error) {
    console.error("Fetching crash events failed:", error);

    return res.status(500).json({
      success: false,
      message: "Could not fetch crash events",
    });
  }
});


/* Create a crash or SOS event */
app.post("/api/crash", authenticateDevice, async (req, res) => {
  const {
    deviceId,
    eventType,
    latitude,
    longitude,
    source,
    acceleration,
    gyro,
    crashConfidence,
  } = req.body ?? {};

  if (
    typeof deviceId !== "string" ||
    !deviceId.trim() ||
    deviceId.length > 100 ||
    !allowedEventTypes.includes(eventType)
  ) {
    return res.status(400).json({
      success: false,
      message: "Valid deviceId and eventType are required",
    });
  }

  if (
    !validCoordinate(latitude, -90, 90) ||
    !validCoordinate(longitude, -180, 180)
  ) {
    return res.status(400).json({
      success: false,
      message: "Invalid latitude or longitude",
    });
  }

  const event = {
    deviceId: deviceId.trim(),
    eventType,
    latitude: latitude ?? null,
    longitude: longitude ?? null,
    source: source === "hardware" ? "hardware" : "simulation",
    acceleration: acceleration ?? null,
    gyro: gyro ?? null,
    crashConfidence: crashConfidence ?? null,
    status: "pending",
    receivedAt: new Date().toISOString(),
  };

  try {
    // 1. Save the event first. Push failure won't undo this.
    const docRef = await db.collection("crash_events").add(event);
    console.log("Crash event saved:", docRef.id);

    // 2. Send push to the rider assigned to this helmet.
    try {
      const deviceDoc = await db
        .collection("devices")
        .doc(event.deviceId)
        .get();

      if (!deviceDoc.exists) {
        console.warn("Device mapping not found:", event.deviceId);
      } else {
        const device = deviceDoc.data();
        const ownerUid = device.ownerUid;

        if (device.enabled !== true || !ownerUid) {
          console.warn(
            "Device disabled or ownerUid missing:",
            event.deviceId
          );
        } else {
          const snapshot = await db
            .collection("push_tokens")
            .where("uid", "==", ownerUid)
            .where("enabled", "==", true)
            .get();

          const title =
            event.eventType === "manual_sos"
              ? "RiderShield Emergency SOS"
              : "RiderShield Crash Alert";

          const body =
            event.eventType === "manual_sos"
              ? "Emergency SOS received. Please check the rider's location."
              : "A possible crash was detected. Please check the rider's status.";

          const pushResults = await Promise.all(
            snapshot.docs.map(async (tokenDoc) => {
              const tokenData = tokenDoc.data();

              if (!tokenData.token) {
                return {
                  success: false,
                  message: "Push token missing",
                };
              }

              try {
                const messageId = await getMessaging().send({
                  token: tokenData.token,
                  notification: { title, body },
                  data: {
                    eventId: docRef.id,
                    eventType: String(event.eventType),
                    deviceId: event.deviceId,
                    latitude: String(event.latitude ?? ""),
                    longitude: String(event.longitude ?? ""),
                  },
                  webpush: {
                    notification: { title, body },
                    fcmOptions: { link: "/" },
                  },
                });

                return { success: true, messageId };
              } catch (pushError) {
                console.error(
                  "Push notification failed:",
                  pushError.message
                );
                return {
                  success: false,
                  message: pushError.message,
                };
              }
            })
          );

          console.log(
            "Crash push results:",
            pushResults.filter((result) => result.success).length,
            "of",
            pushResults.length,
            "sent"
          );
        }
      }
    } catch (pushError) {
      console.error(
        "Crash push processing failed:",
        pushError.message
      );
    }

    // 3. Event remains saved even if push fails.
    return res.status(201).json({
      success: true,
      message: "RiderShield event saved to Firebase",
      eventId: docRef.id,
      event,
    });
  } catch (error) {
    console.error("Firestore save failed:", error);

    return res.status(500).json({
      success: false,
      message: "Could not save event to Firebase",
    });
  }
});

// Update crash event status
app.patch("/api/crash/:eventId/status", async (req, res) => {
  const { eventId } = req.params;
  const { status } = req.body ?? {};

 if (!allowedStatuses.includes(status)) {
  return res.status(400).json({
    success: false,
    message: "Invalid status. Allowed values: " + allowedStatuses.join(", "),
  });
}
  try {
    const docRef = db.collection("crash_events").doc(eventId);
    const doc = await docRef.get();

    if (!doc.exists) {
      return res.status(404).json({
        success: false,
        message: "Crash event not found",
      });
    }

    await docRef.update({
      status,
      updatedAt: FieldValue.serverTimestamp(),
    });

    return res.json({
      success: true,
      message: "Crash event status updated",
      eventId,
      status,
    });
  } catch (error) {
    console.error("Status update failed:", error);

    return res.status(500).json({
      success: false,
      message: "Could not update event status",
    });
  }
});

/* DEMO ONLY: Records intended SMS recipients.
   This route does NOT send real SMS. */
app.post("/api/sms/demo", authenticateUser, async (req, res) => {
  try {
    const snapshot = await db
      .collection("users")
      .doc(req.user.uid)
      .get();

    if (!snapshot.exists) {
      return res.status(404).json({
        success: false,
        message: "Rider profile not found",
      });
    }

    const data = snapshot.data() || {};
const rawContacts = Array.isArray(data.emergencyContacts)
  ? data.emergencyContacts
  : [];

const contacts = rawContacts
  .map((contact) => {
    if (typeof contact === "string") {
      return contact.trim();
    }

    if (contact && typeof contact === "object") {
      return String(contact.phone || "").trim();
    }

    return "";
  })
  .filter((phone) => phone.length > 0);


    const batch = db.batch();
    const demoRecords = [];

    for (const phone of contacts) {
      const ref = db.collection("sms_demo_logs").doc();

      const record = {
        ownerUid: req.user.uid,
        phone,
        message:
          "RiderShield demo: An emergency alert would be sent to this contact.",
        status: "demo_only_not_sent",
        createdAt: FieldValue.serverTimestamp(),
      };

      batch.set(ref, record);
      demoRecords.push({
        demoId: ref.id,
        phone,
        status: record.status,
      });
    }

    await batch.commit();

    return res.status(201).json({
      success: true,
      actualSmsSent: false,
      message: "Demo SMS records created; no SMS was sent.",
      count: demoRecords.length,
      records: demoRecords,
    });
  } catch (error) {
    console.error("SMS demo failed:", error.message);

    return res.status(500).json({
      success: false,
      message: "Could not create SMS demo records",
    });
  }
});

// Check push routes
app.get("/api/push/check", (req, res) => {
  res.json({
    success: true,
    route: "RiderShield push API is running",
  });
});

// Register FCM token for the authenticated Firebase user
app.post("/api/push/register", authenticateUser, async (req, res) => {
  const { token } = req.body ?? {};

  if (
    typeof token !== "string" ||
    token.trim().length < 20 ||
    token.length > 4096
  ) {
    return res.status(400).json({
      success: false,
      message: "A valid FCM token is required",
    });
  }

  try {
    const tokenId = crypto
      .createHash("sha256")
      .update(token.trim())
      .digest("hex");

    await db.collection("push_tokens").doc(tokenId).set({
      uid: req.user.uid,
      token: token.trim(),
      platform: "web",
      enabled: true,
      updatedAt: FieldValue.serverTimestamp(),
    });

    return res.status(200).json({
      success: true,
      message: "Push token registered",
    });
  } catch (error) {
    console.error("Push token registration failed:", error.message);

    return res.status(500).json({
      success: false,
      message: "Could not register push token",
    });
  }
});

// Send a test push to this authenticated user's registered devices
app.post("/api/push/test", authenticateUser, async (req, res) => {
  try {
    const snapshot = await db
      .collection("push_tokens")
      .where("uid", "==", req.user.uid)
      .where("enabled", "==", true)
      .get();

    if (snapshot.empty) {
      return res.status(404).json({
        success: false,
        message: "No registered push token for this user",
      });
    }

    const results = await Promise.all(
      snapshot.docs.map(async (doc) => {
        const data = doc.data();

        try {
          const messageId = await getMessaging().send({
            token: data.token,
            notification: {
              title: "RiderShield Test",
              body: "Push notifications are working!",
            },
            webpush: {
              notification: {
                title: "RiderShield Test",
                body: "Push notifications are working!",
              },
            },
          });

          return {
            success: true,
            messageId,
          };
        } catch (error) {
          console.error("FCM send failed:", error.message);

          return {
            success: false,
            message: error.message,
          };
        }
      })
    );

    const sent = results.filter((item) => item.success).length;

    return res.status(sent > 0 ? 200 : 500).json({
      success: sent > 0,
      sent,
      total: results.length,
      results,
    });
  } catch (error) {
    console.error("Test push failed:", error);

    return res.status(500).json({
      success: false,
      message: "Test push failed",
    });
  }
});

// Send a real emergency SMS to the authenticated user's saved contacts.
// Required backend environment variables: TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN,
// TWILIO_PHONE_NUMBER. Install the SDK with: npm install twilio
app.post("/api/sms/emergency", authenticateUser, async (req, res) => {
  try {
    const { latitude, longitude, eventType } = req.body ?? {};
    if (
      typeof latitude !== "number" || !Number.isFinite(latitude) || latitude < -90 || latitude > 90 ||
      typeof longitude !== "number" || !Number.isFinite(longitude) || longitude < -180 || longitude > 180
    ) {
      return res.status(400).json({ success: false, message: "Valid GPS latitude and longitude are required." });
    }

    const sid = process.env.TWILIO_ACCOUNT_SID;
    const token = process.env.TWILIO_AUTH_TOKEN;
    const from = process.env.TWILIO_PHONE_NUMBER;
    if (!sid || !token || !from) {
      return res.status(503).json({ success: false, message: "Twilio is not configured on the backend yet." });
    }

    const profileSnap = await db.collection("users").doc(req.user.uid).get();
    if (!profileSnap.exists) {
      return res.status(404).json({ success: false, message: "Rider profile not found in users collection." });
    }
    const profile = profileSnap.data() || {};
    const rawContacts = Array.isArray(profile.emergencyContacts) ? profile.emergencyContacts : [];
    const contacts = [...new Set(rawContacts.map((c) => {
      if (typeof c === "string") return c.trim();
      if (c && typeof c === "object") return String(c.phone || c.phoneNumber || c.mobileNumber || "").trim();
      return "";
    }).filter((phone) => /^\+[1-9]\d{7,14}$/.test(phone)))];

    if (!contacts.length) {
      return res.status(400).json({ success: false, message: "No valid emergency contact numbers found. Save numbers in international format, e.g. +91XXXXXXXXXX." });
    }

    const twilio = require("twilio")(sid, token);
    const riderName = String(profile.name || profile.fullName || profile.displayName || req.user.name || "Rider").slice(0, 100);
    const riderPhone = String(profile.phone || profile.phoneNumber || profile.mobileNumber || "Not available").slice(0, 40);
    const mapUrl = `https://www.google.com/maps?q=${latitude},${longitude}`;
    const message = [
      "🚨 RIDERSHIELD EMERGENCY ALERT",
      `Event: ${eventType === "manual_sos" ? "Manual SOS" : "Possible crash detected"}`,
      `Rider: ${riderName}`,
      `Phone: ${riderPhone}`,
      `Time: ${new Date().toISOString()}`,
      `GPS: ${latitude}, ${longitude}`,
      `Map: ${mapUrl}`,
      "Please contact the rider and arrange assistance."
    ].join("\n");

    const results = await Promise.all(contacts.map(async (to) => {
      try {
        const sent = await twilio.messages.create({ body: message, from, to });
        await db.collection("sms_logs").add({
          ownerUid: req.user.uid, to, riderName, latitude, longitude,
          eventType: eventType === "manual_sos" ? "manual_sos" : "possible_crash",
          messageSid: sent.sid, status: sent.status || "queued", createdAt: FieldValue.serverTimestamp()
        });
        return { success: true, to, sid: sent.sid, status: sent.status || "queued" };
      } catch (sendError) {
        console.error("Twilio SMS failed for contact:", to, sendError.message);
        await db.collection("sms_logs").add({
          ownerUid: req.user.uid, to, riderName, latitude, longitude,
          eventType: eventType === "manual_sos" ? "manual_sos" : "possible_crash",
          status: "failed", error: String(sendError.message || "Twilio send failed").slice(0, 300),
          createdAt: FieldValue.serverTimestamp()
        });
        return { success: false, to, error: String(sendError.message || "SMS failed").slice(0, 200) };
      }
    }));

    const sentCount = results.filter((r) => r.success).length;
    return res.status(sentCount > 0 ? 200 : 502).json({
      success: sentCount > 0, actualSmsSent: sentCount > 0, sent: sentCount,
      total: contacts.length, riderName, riderPhone, latitude, longitude, mapUrl, results
    });
  } catch (error) {
    console.error("Emergency SMS route failed:", error.message);
    return res.status(500).json({ success: false, message: "Emergency SMS request failed." });
  }
});


app.post("/api/sms/send-emergency", authenticateUser, async (req, res) => {
  try {
    const { latitude, longitude, riderName, riderPhone } = req.body ?? {};

    if (
      !Number.isFinite(Number(latitude)) ||
      !Number.isFinite(Number(longitude)) ||
      Number(latitude) < -90 ||
      Number(latitude) > 90 ||
      Number(longitude) < -180 ||
      Number(longitude) > 180
    ) {
      return res.status(400).json({
        success: false,
        message: "Valid GPS coordinates are required",
      });
    }

    const accountSid = process.env.TWILIO_ACCOUNT_SID;
    const authToken = process.env.TWILIO_AUTH_TOKEN;
    const from = process.env.TWILIO_PHONE_NUMBER;

    if (!accountSid || !authToken || !from) {
      return res.status(500).json({
        success: false,
        message: "Twilio environment variables are missing",
      });
    }

    const userDoc = await db.collection("users")
      .doc(req.user.uid).get();

    if (!userDoc.exists) {
      return res.status(404).json({
        success: false,
        message: "Rider profile not found",
      });
    }

    const profile = userDoc.data() || {};
    const contacts = (Array.isArray(profile.emergencyContacts)
      ? profile.emergencyContacts
      : [])
      .map(c => typeof c === "string" ? c.trim() : String(c?.phone || "").trim())
      .filter(Boolean);

    if (!contacts.length) {
      return res.status(400).json({
        success: false,
        message: "No saved emergency contacts found",
      });
    }

    const lat = Number(latitude);
    const lon = Number(longitude);
    const mapsUrl = `https://www.google.com/maps?q=${lat},${lon}`;

    const message =
      `🚨 RIDERSHIELD EMERGENCY ALERT\n` +
      `Possible crash detected.\n` +
      `Rider: ${String(riderName || profile.name || "Rider").slice(0, 80)}\n` +
      `Phone: ${String(riderPhone || profile.phone || "Not available").slice(0, 25)}\n` +
      `Location: ${lat}, ${lon}\n` +
      `Map: ${mapsUrl}\n` +
      `Please contact the rider immediately.`;

    const client = require("twilio")(accountSid, authToken);

    const results = await Promise.all(contacts.map(async phone => {
      try {
        const sent = await client.messages.create({
          body: message,
          from,
          to: phone,
        });

        await db.collection("sms_logs").add({
          ownerUid: req.user.uid,
          phone,
          eventType: "emergency",
          status: sent.status || "accepted",
          messageSid: sent.sid,
          createdAt: FieldValue.serverTimestamp(),
        });

        return { phone, success: true, status: sent.status };
      } catch (err) {
        console.error("SMS send failed:", err.message);
        return { phone, success: false, error: err.message };
      }
    }));

    return res.status(200).json({
      success: results.some(r => r.success),
      results,
    });
  } catch (err) {
    console.error("Emergency SMS route failed:", err.message);
    return res.status(500).json({
      success: false,
      message: "Emergency SMS request failed",
    });
  }
});
app.listen(PORT, () => {
  console.log("RiderShield API running on port " + PORT);
});
 