#include <WiFi.h>
#include <esp_now.h>
#include <esp_wifi.h>
#include <string.h>

#define BUZZER_PIN 25
#define LED_PIN 26

// Must match sender's actual Wi-Fi channel.
#define RECEIVER_CHANNEL 3

const unsigned long ALARM_DURATION = 2000;

volatile bool crashMessage = false;
volatile bool safeMessage = false;

bool alarmActive = false;
unsigned long alarmStartedAt = 0;

void onDataRecv(const esp_now_recv_info_t *info,
                const uint8_t *data, int len) {
  if (len <= 0 || len >= 20) return;

  char message[20];
  memcpy(message, data, len);
  message[len] = '\0';

  Serial.print("ESP-NOW message received: ");
  Serial.println(message);

  if (strcmp(message, "SOS") == 0 ||
      strcmp(message, "CRASH") == 0) {
    crashMessage = true;
  } else if (strcmp(message, "SAFE") == 0) {
    safeMessage = true;
  } else {
    Serial.println("Unknown message");
  }
}

void stopAlarm() {
  digitalWrite(BUZZER_PIN, LOW);
  digitalWrite(LED_PIN, LOW);
  alarmActive = false;
  Serial.println("Receiver buzzer OFF; LED OFF");
}

void setup() {
  Serial.begin(115200);
  delay(500);

  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(LED_PIN, OUTPUT);

  digitalWrite(BUZZER_PIN, LOW);
  digitalWrite(LED_PIN, LOW);

  Serial.println("\nRiderShield Receiver Starting...");

  // Startup test: alarm outputs for 2 seconds.
  Serial.println("Testing alarm outputs...");
  digitalWrite(LED_PIN, HIGH);
  digitalWrite(BUZZER_PIN, HIGH);
  delay(2000);
  digitalWrite(LED_PIN, LOW);
  digitalWrite(BUZZER_PIN, LOW);

  WiFi.mode(WIFI_STA);
  WiFi.disconnect();
  delay(200);

  esp_err_t channelResult = esp_wifi_set_channel(
    RECEIVER_CHANNEL, WIFI_SECOND_CHAN_NONE
  );

  Serial.print("Channel set result: ");
  Serial.println((int)channelResult);

  Serial.print("Receiver MAC: ");
  Serial.println(WiFi.macAddress());

  uint8_t primary = 0;
  wifi_second_chan_t secondary;
  esp_wifi_get_channel(&primary, &secondary);

  Serial.print("Receiver Wi-Fi channel: ");
  Serial.println(primary);

  if (esp_now_init() != ESP_OK) {
    Serial.println("ESP_NOW_INIT_FAILED");
    while (true) delay(1000);
  }

  esp_now_register_recv_cb(onDataRecv);
  Serial.println("Receiver READY");
}

void loop() {
  // SAFE has priority: stop the alarm immediately.
  if (safeMessage) {
    safeMessage = false;
    crashMessage = false;
    stopAlarm();
    Serial.println("Rider marked SAFE");
  } else if (crashMessage) {
    crashMessage = false;

    digitalWrite(BUZZER_PIN, HIGH);
    digitalWrite(LED_PIN, HIGH);

    alarmActive = true;
    alarmStartedAt = millis();

    Serial.println("!!! EMERGENCY ALERT !!!");
    Serial.println("Buzzer and LED ON for 2 seconds");
  }

  // Automatically stop alarm after 2 seconds.
  if (alarmActive &&
      millis() - alarmStartedAt >= ALARM_DURATION) {
    stopAlarm();
  }

  delay(10);
}