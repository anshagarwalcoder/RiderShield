#include <WiFi.h>
#include <esp_now.h>
#include <esp_wifi.h>
#include <esp_eap_client.h>
#include <Wire.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>
#include <math.h>
#include <string.h>

// ========== IITG_CONNECT ENTERPRISE WIFI ==========
const char* WIFI_SSID = "IITG_CONNECT";

#define EAP_IDENTITY "ev_vidya26"
#define EAP_USERNAME "ev_vidya26"
#define EAP_PASSWORD "KL18%%ru"

// ========== RIDERSHIELD BACKEND ==========
const char* SERVER_URL =
  "https://processes-judges-stones-mega.trycloudflare.com/api/crash";

const char* RIDERSHIELD_API_KEY = "ce85961397620df10f6ca3262626444e1546b776f630e83b60ff55351ac1af77";

// ========== HARDWARE PINS ==========
#define SDA_PIN 21
#define SCL_PIN 22
#define BUZZER_PIN 25
#define MPU_ADDR 0x68

// ========== ESP-NOW RECEIVER MAC ==========
uint8_t receiverAddress[] = {
  0x58, 0x2A, 0xBD, 0x77, 0x62, 0x9C
};

// ========== CRASH DETECTION ==========
const float ACCEL_CHANGE = 0.18;
const float GYRO_LIMIT = 80.0;

const unsigned long EVENT_COOLDOWN = 15000;
const unsigned long BUZZER_DURATION = 2000;

unsigned long lastEventTime = 0;
unsigned long buzzerStartTime = 0;

bool crashDetected = false;
bool buzzerActive = false;

float previousAccel = 1.0;

// ========== MPU6050 READ ==========
bool readMPU(
  float &ax, float &ay, float &az,
  float &gx, float &gy, float &gz
) {
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(0x3B);

  if (Wire.endTransmission(false) != 0) {
    return false;
  }

  if (Wire.requestFrom(MPU_ADDR, 14, true) != 14) {
    return false;
  }

  int16_t rawAX = (Wire.read() << 8) | Wire.read();
  int16_t rawAY = (Wire.read() << 8) | Wire.read();
  int16_t rawAZ = (Wire.read() << 8) | Wire.read();

  Wire.read();
  Wire.read(); // Temperature

  int16_t rawGX = (Wire.read() << 8) | Wire.read();
  int16_t rawGY = (Wire.read() << 8) | Wire.read();
  int16_t rawGZ = (Wire.read() << 8) | Wire.read();

  ax = rawAX / 16384.0;
  ay = rawAY / 16384.0;
  az = rawAZ / 16384.0;

  gx = rawGX / 131.0;
  gy = rawGY / 131.0;
  gz = rawGZ / 131.0;

  return true;
}

// ========== BUZZER ==========
void startBuzzer() {
  digitalWrite(BUZZER_PIN, HIGH);
  buzzerStartTime = millis();
  buzzerActive = true;
}

void updateBuzzer() {
  if (buzzerActive &&
      millis() - buzzerStartTime >= BUZZER_DURATION) {
    digitalWrite(BUZZER_PIN, LOW);
    buzzerActive = false;
    Serial.println("Sender buzzer OFF");
  }
}

// ========== SEND ESP-NOW SOS ==========
void sendSOS() {
  const char message[] = "SOS";

  esp_err_t result = esp_now_send(
    receiverAddress,
    (const uint8_t*)message,
    sizeof(message)
  );

  if (result == ESP_OK) {
    Serial.println("SOS sent to receiver.");
  } else {
    Serial.printf("ESP-NOW send failed: %d\n", result);
  }
}

// ========== SEND BACKEND EVENT ==========
void sendBackendEvent(
  float ax, float ay, float az,
  float gx, float gy, float gz
) {
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("Wi-Fi disconnected; backend event not sent.");
    return;
  }

  WiFiClientSecure client;

  // Temporary demo only; does not verify server certificate.
  client.setInsecure();

  HTTPClient http;
  http.setTimeout(10000);

  if (!http.begin(client, SERVER_URL)) {
    Serial.println("HTTPS initialization failed.");
    return;
  }

  http.addHeader("Content-Type", "application/json");
  http.addHeader("x-api-key", RIDERSHIELD_API_KEY);

  float acceleration =
    sqrt(ax * ax + ay * ay + az * az);

  float gyro =
    sqrt(gx * gx + gy * gy + gz * gz);

  // DEMO coordinates only, not live GPS.
  String payload = "{";
  payload += "\"deviceId\":\"helmet-01\",";
  payload += "\"eventType\":\"possible_crash\",";
  payload += "\"latitude\":26.14,";
  payload += "\"longitude\":91.66,";
  payload += "\"source\":\"hardware\",";
  payload += "\"acceleration\":" + String(acceleration, 3) + ",";
  payload += "\"gyro\":" + String(gyro, 2);
  payload += "}";

  Serial.println("Sending event to backend...");

  int httpCode = http.POST(payload);

  Serial.printf("Backend HTTP code: %d\n", httpCode);

  if (httpCode > 0) {
    String response = http.getString();
    Serial.println("Backend response:");
    Serial.println(response);

    if (httpCode == 201) {
      Serial.println("SOS EVENT ACCEPTED BY BACKEND");
    }
  } else {
    Serial.printf(
      "HTTPS error: %s\n",
      http.errorToString(httpCode).c_str()
    );
  }

  http.end();
  client.stop();
}

// ========== ENTERPRISE WIFI CONNECTION ==========
bool connectEnterpriseWiFi() {
  WiFi.mode(WIFI_STA);
  WiFi.disconnect();
  delay(500);

  Serial.println("Configuring IITG_CONNECT PEAP...");

  esp_err_t err;

  err = esp_eap_client_set_identity(
    (const uint8_t*)EAP_IDENTITY,
    strlen(EAP_IDENTITY)
  );

  if (err != ESP_OK) {
    Serial.printf("EAP identity setup failed: %d\n", err);
    return false;
  }

  err = esp_eap_client_set_username(
    (const uint8_t*)EAP_USERNAME,
    strlen(EAP_USERNAME)
  );

  if (err != ESP_OK) {
    Serial.printf("EAP username setup failed: %d\n", err);
    return false;
  }

  err = esp_eap_client_set_password(
    (const uint8_t*)EAP_PASSWORD,
    strlen(EAP_PASSWORD)
  );

  if (err != ESP_OK) {
    Serial.printf("EAP password setup failed: %d\n", err);
    return false;
  }

  // Enable WPA-Enterprise authentication.
  err = esp_wifi_sta_enterprise_enable();

  if (err != ESP_OK) {
    Serial.printf("Enterprise enable failed: %d\n", err);
    return false;
  }

  Serial.println("Connecting to IITG_CONNECT...");

  // Credentials are configured above.
  WiFi.begin(WIFI_SSID);

  unsigned long startAttempt = millis();

  while (WiFi.status() != WL_CONNECTED &&
         millis() - startAttempt < 30000) {
    delay(500);
    Serial.print(".");
  }

  Serial.println();

  if (WiFi.status() != WL_CONNECTED) {
    Serial.printf(
      "Wi-Fi connection failed. Status: %d\n",
      WiFi.status()
    );
    return false;
  }

  Serial.println("IITG_CONNECT connected!");
  Serial.print("ESP32 IP: ");
  Serial.println(WiFi.localIP());

  Serial.print("ESP32 Wi-Fi channel: ");
  Serial.println(WiFi.channel());

  return true;
}

// ========== ESP-NOW INITIALIZATION ==========
bool setupESPNow() {
  if (esp_now_init() != ESP_OK) {
    Serial.println("ESP-NOW initialization failed.");
    return false;
  }

  esp_now_peer_info_t peerInfo = {};

  memcpy(
    peerInfo.peer_addr,
    receiverAddress,
    sizeof(receiverAddress)
  );

  // Channel 0 means use the ESP32's current channel.
  peerInfo.channel = 0;
  peerInfo.encrypt = false;

  esp_err_t result = esp_now_add_peer(&peerInfo);

  if (result != ESP_OK && result != ESP_ERR_ESPNOW_EXIST) {
    Serial.printf("Adding receiver failed: %d\n", result);
    return false;
  }

  Serial.println("ESP-NOW receiver ready.");
  return true;
}

// ========== SETUP ==========
void setup() {
  Serial.begin(115200);
  delay(500);

  pinMode(BUZZER_PIN, OUTPUT);
  digitalWrite(BUZZER_PIN, LOW);

  Wire.begin(SDA_PIN, SCL_PIN);

  // Wake up MPU6050.
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(0x6B);
  Wire.write(0x00);

  if (Wire.endTransmission() == 0) {
    Serial.println("MPU6050 detected.");
  } else {
    Serial.println("WARNING: MPU6050 not detected.");
  }

  // Connect to enterprise Wi-Fi first.
  bool wifiConnected = connectEnterpriseWiFi();

  // Initialize ESP-NOW even if Wi-Fi fails.
  // Backend requests require Wi-Fi to be connected.
  if (!setupESPNow()) {
    Serial.println("Check receiver MAC and ESP-NOW setup.");
  }

  if (!wifiConnected) {
    Serial.println("Backend sending unavailable until Wi-Fi connects.");
  }

  Serial.println("RiderShield sender ready.");
}

// ========== MAIN LOOP ==========
void loop() {
  updateBuzzer();

  float ax, ay, az, gx, gy, gz;

  if (!readMPU(ax, ay, az, gx, gy, gz)) {
    delay(200);
    return;
  }

  float accelMagnitude =
    sqrt(ax * ax + ay * ay + az * az);

  float gyroMagnitude =
    sqrt(gx * gx + gy * gy + gz * gz);

  float accelChange =
    fabs(accelMagnitude - previousAccel);

  previousAccel = accelMagnitude;

  bool possibleCrash =
    (accelChange >= ACCEL_CHANGE) ||
    (gyroMagnitude >= GYRO_LIMIT);

  if (possibleCrash &&
      !crashDetected &&
      millis() - lastEventTime >= EVENT_COOLDOWN) {

    crashDetected = true;
    lastEventTime = millis();

    Serial.println("Possible crash detected!");

    startBuzzer();
    sendSOS();

    sendBackendEvent(ax, ay, az, gx, gy, gz);
  }

  delay(100);
}